/* SPDX-License-Identifier: GPL-3.0-or-later */

#include "instance.hpp"

#include "device_selection.hpp"
#include "frame_generation_backend.hpp"
#include "layer_role.hpp"
#include "pnext_chain.hpp"
#include "present_diagnostics.hpp"
#include "spatial_scaling_policy.hpp"
#include "swapchain/create_policy.hpp"
#include "swapchain/swapchain.hpp"

#include "mako-backend/device_identity.hpp"
#include "mako-common/configuration/detection.hpp"
#include "mako-common/helpers/errors.hpp"
#include "mako-common/helpers/paths.hpp"
#include "mako-common/vulkan/vulkan.hpp"

#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <cstdlib>
#include <exception>
#include <filesystem>
#include <functional>
#include <iostream>
#include <limits>
#include <optional>
#include <sstream>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <stdlib.h>
#include <unistd.h>
#include <vulkan/vulkan_core.h>

using namespace mako;
using namespace mako::layer;

#ifndef MAKO_BUILD_VERSION
#define MAKO_BUILD_VERSION "unknown"
#endif
#ifndef MAKO_BUILD_FINGERPRINT
#define MAKO_BUILD_FINGERPRINT MAKO_BUILD_VERSION
#endif

namespace {
    constexpr uint64_t spatialScalingEnabledBit = uint64_t{1};
    constexpr uint64_t spatialScalingProcessSupportedBit = uint64_t{2};
    constexpr uint64_t spatialScalingSupersamplingBit = uint64_t{4};

    vk::DeviceMemoryTotals memoryDelta(
            const vk::DeviceMemoryTotals& after,
            const vk::DeviceMemoryTotals& before) {
        return {
            .bytes = after.bytes >= before.bytes
                ? after.bytes - before.bytes
                : 0,
            .allocations = after.allocations >= before.allocations
                ? after.allocations - before.allocations
                : 0,
        };
    }

#if defined(MAKO_LAYER_ROLE_SPATIAL_SCALING)
    constexpr char makoBuildIdentity[] =
        "MAKO Renderer: render layer active; identity="
        "VK_LAYER_MAKO_spatial_scaling; build="
        MAKO_BUILD_VERSION
        "; fingerprint="
        MAKO_BUILD_FINGERPRINT
        "; role=spatial-scaling";
#else
    constexpr char makoBuildIdentity[] =
        "MAKO Renderer: render layer active; identity="
        "VK_LAYER_MAKO_render; build="
        MAKO_BUILD_VERSION
        "; fingerprint="
        MAKO_BUILD_FINGERPRINT
        "; role=frame-generation";
#endif

    std::string diagnosticToken(const std::string_view raw) {
        if (raw.empty())
            return "(unset)";

        const auto separator = raw.find_last_of("/\\");
        std::string token(raw.substr(
            separator == std::string_view::npos ? 0 : separator + 1
        ));
        for (char& character : token) {
            if (character == ' ' || character == '\t' ||
                    character == '\r' || character == '\n' ||
                    character == '=') {
                character = '_';
            }
        }
        return token.empty() ? "(unset)" : token;
    }

    std::string_view identificationToken(const ls::IdentType type) {
        switch (type) {
            case ls::IdentType::OVERRIDE:
                return "override";
            case ls::IdentType::EXECUTABLE:
                return "executable";
            case ls::IdentType::WINE_EXECUTABLE:
                return "wine-executable";
            case ls::IdentType::PROCESS_NAME:
                return "process-name";
            case ls::IdentType::FALLBACK:
                return "fallback";
        }
        return "unknown";
    }

    bool physicalDeviceSupportsExtension(
            const vk::VulkanInstanceFuncs& funcs,
            const VkPhysicalDevice physicalDevice,
            const std::string_view name) {
        uint32_t extensionCount{};
        auto result = funcs.EnumerateDeviceExtensionProperties(
            physicalDevice, nullptr, &extensionCount, nullptr
        );
        if (result != VK_SUCCESS)
            return false;
        std::vector<VkExtensionProperties> extensions(extensionCount);
        result = funcs.EnumerateDeviceExtensionProperties(
            physicalDevice, nullptr, &extensionCount, extensions.data()
        );
        return result == VK_SUCCESS && std::ranges::any_of(
            extensions,
            [name](const VkExtensionProperties& extension) {
                return name == extension.extensionName;
            }
        );
    }

    std::optional<backend::DriverIdentity> identifyApplicationDriver(
            const vk::Vulkan& vk) {
        const auto& funcs = vk.fi();
        if (!funcs.GetPhysicalDeviceProperties2)
            return std::nullopt;
        VkPhysicalDeviceIDProperties ids{
            .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_ID_PROPERTIES
        };
        VkPhysicalDeviceProperties2 properties{
            .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2,
            .pNext = &ids
        };
        funcs.GetPhysicalDeviceProperties2(vk.physdev(), &properties);
        backend::DriverIdentity identity;
        std::ranges::copy(ids.driverUUID, identity.driver.begin());
        std::ranges::copy(ids.deviceUUID, identity.device.begin());
        return identity;
    }

    PhysicalDeviceIdentity identifyApplicationDevice(const vk::Vulkan& vk) {
        const auto& funcs = vk.fi();
        const auto physicalDevice = vk.physdev();

        uint32_t extensionCount{};
        funcs.EnumerateDeviceExtensionProperties(
            physicalDevice, nullptr, &extensionCount, VK_NULL_HANDLE
        );
        std::vector<VkExtensionProperties> extensions(extensionCount);
        funcs.EnumerateDeviceExtensionProperties(
            physicalDevice, nullptr, &extensionCount, extensions.data()
        );
        const bool hasPciInfo = std::ranges::find_if(
            extensions,
            [](const VkExtensionProperties& extension) {
                return std::string(extension.extensionName)
                    == VK_EXT_PCI_BUS_INFO_EXTENSION_NAME;
            }
        ) != extensions.end();

        VkPhysicalDevicePCIBusInfoPropertiesEXT pciInfo{
            .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PCI_BUS_INFO_PROPERTIES_EXT
        };
        VkPhysicalDeviceProperties2 properties{
            .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2,
            .pNext = hasPciInfo && funcs.GetPhysicalDeviceProperties2
                ? &pciInfo : nullptr
        };
        if (funcs.GetPhysicalDeviceProperties2) {
            funcs.GetPhysicalDeviceProperties2(physicalDevice, &properties);
        } else {
            funcs.GetPhysicalDeviceProperties(
                physicalDevice, &properties.properties
            );
        }

        std::array<char, VK_MAX_PHYSICAL_DEVICE_NAME_SIZE> deviceName{};
        std::copy_n(
            properties.properties.deviceName,
            deviceName.size() - 1,
            deviceName.begin()
        );

        return {
            .name = deviceName.data(),
            .vendorId = backend::deviceIdText(properties.properties.vendorID),
            .deviceId = backend::deviceIdText(properties.properties.deviceID),
            .pci = hasPciInfo && funcs.GetPhysicalDeviceProperties2
                ? std::optional<std::string>{
                    backend::pciAddressText(pciInfo.pciBus, pciInfo.pciDevice,
                        pciInfo.pciFunction)
                }
                : std::nullopt,
        };
    }

    class ScopedEnvironmentOverride {
    public:
        ScopedEnvironmentOverride(std::string name, const char* value) :
                name(std::move(name)) {
            if (const char* current = std::getenv(this->name.c_str()))
                this->previousValue = current;

            if (setenv(this->name.c_str(), value, 1) != 0)
                throw ls::error("unable to set environment override: " + this->name);
        }

        ~ScopedEnvironmentOverride() {
            if (this->previousValue)
                static_cast<void>(setenv(
                    this->name.c_str(), this->previousValue->c_str(), 1
                ));
            else
                static_cast<void>(unsetenv(this->name.c_str()));
        }

        ScopedEnvironmentOverride(const ScopedEnvironmentOverride&) = delete;
        ScopedEnvironmentOverride& operator=(const ScopedEnvironmentOverride&) = delete;
        ScopedEnvironmentOverride(ScopedEnvironmentOverride&&) = delete;
        ScopedEnvironmentOverride& operator=(ScopedEnvironmentOverride&&) = delete;

    private:
        std::string name;
        std::optional<std::string> previousValue;
    };

    std::string hdrFeedbackDiagnosticKey(
            const GamescopeHdrFeedbackSample& sample) {
        const auto booleanToken = [](const std::optional<bool> value) {
            return value ? (*value ? "1" : "0") : "unknown";
        };
        return sample.status + '\n' + sample.display + '\n' +
            sample.activationSource + '\n' +
            sample.resolverStatus + '\n' + sample.resolverCandidates + '\n' +
            (sample.active
                ? (*sample.active ? "active" : "inactive") : "unknown") + '\n' +
            std::to_string(sample.gamescopePid.value_or(UINT32_MAX)) + '\n' +
            std::to_string(sample.xwaylandServerId.value_or(UINT32_MAX)) + '\n' +
            std::to_string(sample.outputWidth.value_or(0)) + 'x' +
            std::to_string(sample.outputHeight.value_or(0)) + '\n' +
            std::to_string(sample.refreshHz.value_or(0)) + '\n' +
            booleanToken(sample.presentation.vrrEnabled) + '\n' +
            booleanToken(sample.presentation.vrrCapable) + '\n' +
            booleanToken(sample.presentation.vrrActive) + '\n' +
            booleanToken(sample.presentation.allowTearing) + '\n' +
            (sample.outputHdrEnabled
                ? (*sample.outputHdrEnabled ? "output-hdr" : "output-sdr")
                : "output-unknown") + '\n' +
            (sample.appHdrMetadataPresent ? "metadata" : "no-metadata");
    }

    void logHdrFeedbackDiagnostic(
            const char* prefix,
            const GamescopeHdrFeedbackSample& sample) {
        std::cerr << prefix << sample.status
                  << "; display="
                  << (sample.display.empty() ? "(unset)" : sample.display)
                  << "; resolver="
                  << (sample.resolverStatus.empty()
                        ? "(unset)" : sample.resolverStatus)
                  << "; gamescope_pid="
                  << sample.gamescopePid.value_or(UINT32_MAX)
                  << "; server_id="
                  << sample.xwaylandServerId.value_or(UINT32_MAX)
                  << "; refresh_hz="
                  << sample.refreshHz.value_or(0)
                  << "; presentation_target="
                  << sample.outputWidth.value_or(0) << 'x'
                  << sample.outputHeight.value_or(0)
                  << "; active=";
        if (sample.active)
            std::cerr << (*sample.active ? 1 : 0);
        else
            std::cerr << "unknown";
        std::cerr
                  << "; activation_source="
                  << (sample.activationSource.empty()
                        ? "unavailable" : sample.activationSource)
                  << "; output_hdr=";
        if (sample.outputHdrEnabled)
            std::cerr << (*sample.outputHdrEnabled ? 1 : 0);
        else
            std::cerr << "unknown";
        std::cerr << "; vrr_enabled=";
        if (sample.presentation.vrrEnabled)
            std::cerr << (*sample.presentation.vrrEnabled ? 1 : 0);
        else
            std::cerr << "unknown";
        std::cerr << "; vrr_capable=";
        if (sample.presentation.vrrCapable)
            std::cerr << (*sample.presentation.vrrCapable ? 1 : 0);
        else
            std::cerr << "unknown";
        std::cerr << "; vrr_active=";
        if (sample.presentation.vrrActive)
            std::cerr << (*sample.presentation.vrrActive ? 1 : 0);
        else
            std::cerr << "unknown";
        std::cerr << "; allow_tearing=";
        if (sample.presentation.allowTearing)
            std::cerr << (*sample.presentation.allowTearing ? 1 : 0);
        else
            std::cerr << "unknown";
        std::cerr
                  << "; app_hdr_metadata="
                  << (sample.appHdrMetadataPresent ? 1 : 0)
                  << "; candidates="
                  << (sample.resolverCandidates.empty()
                        ? "(none)" : sample.resolverCandidates)
                  << '\n';
    }

    /// helper function to add required extensions
    std::vector<const char*> add_extensions(const char* const* existingExtensions, size_t count,
            const std::vector<const char*>& requiredExtensions) {
        std::vector<const char*> extensions(count);
        std::copy_n(existingExtensions, count, extensions.data());

        for (const auto& requiredExtension : requiredExtensions) {
            auto it = std::ranges::find_if(extensions,
                [requiredExtension](const char* extension) {
                    return std::string(extension) == std::string(requiredExtension);
                });
            if (it == extensions.end())
                extensions.push_back(requiredExtension);
        }

        return extensions;
    }
}

void Root::publishSurfaceScalingPolicy() noexcept {
    const bool enabled = this->active_profile &&
        ls::spatialScalingRequested(*this->active_profile);
    const float factor = this->active_profile
        ? this->active_profile->scaling_factor : 1.0F;
    const bool supersampling = this->active_profile &&
        this->active_profile->scaling_supersampling;
    const bool processSupported = spatialScalingProcessSupported(
        this->gamescopeEnvironmentDetected,
        this->gamescopeDetected,
        this->presentationEnvironment.hdrExposureDisabled,
        this->presentationEnvironment.gamescopeWsiDisabled
    );
    const uint64_t packedFactor = static_cast<uint64_t>(
        std::bit_cast<uint32_t>(factor)
    ) << 32U;
    const uint64_t packed = packedFactor |
        (enabled ? spatialScalingEnabledBit : uint64_t{0}) |
        (supersampling
            ? spatialScalingSupersamplingBit : uint64_t{0}) |
        (processSupported
            ? spatialScalingProcessSupportedBit : uint64_t{0});
    const uint64_t observedSequence =
        this->surfaceScalingPolicySequence.load(std::memory_order_acquire);
    if ((observedSequence & uint64_t{1}) == 0 &&
            this->surfaceScalingPolicy.load(std::memory_order_acquire) ==
                packed &&
            this->surfaceScalingPolicySequence.load(
                std::memory_order_acquire
            ) == observedSequence) {
        return;
    }

    const std::lock_guard lock(this->surfaceScalingPolicyPublishMutex);
    if (this->surfaceScalingPolicy.load(std::memory_order_relaxed) == packed)
        return;

    this->surfaceScalingPolicySequence.fetch_add(
        1, std::memory_order_acq_rel
    );
    this->surfaceScalingPolicy.store(packed, std::memory_order_release);
    this->surfaceScalingPolicySequence.fetch_add(
        1, std::memory_order_release
    );
}

SpatialScalingPolicySnapshot Root::surfaceScalingPolicySnapshot()
        const noexcept {
    while (true) {
        const uint64_t sequenceBefore =
            this->surfaceScalingPolicySequence.load(std::memory_order_acquire);
        if ((sequenceBefore & uint64_t{1}) != 0)
            continue;
        const uint64_t packed = this->surfaceScalingPolicy.load(
            std::memory_order_acquire
        );
        const uint64_t sequenceAfter =
            this->surfaceScalingPolicySequence.load(std::memory_order_acquire);
        if (sequenceBefore != sequenceAfter)
            continue;

        return SpatialScalingPolicySnapshot{
            .policy = {
                .enabled = (packed & spatialScalingEnabledBit) != 0,
                .factor = std::bit_cast<float>(
                    static_cast<uint32_t>(packed >> 32U)
                ),
                .supersampling =
                    (packed & spatialScalingSupersamplingBit) != 0,
            },
            .processSupported =
                (packed & spatialScalingProcessSupportedBit) != 0,
            .revision = sequenceAfter / 2,
        };
    }
}

Root::Root() :
    presentationEnvironment(resolvePresentationEnvironmentPolicy(
        std::getenv("MAKO_DISABLE_HDR_EXPOSURE"),
        std::getenv("DXVK_HDR"),
        std::getenv("DISABLE_GAMESCOPE_WSI")
    )),
    gamescopeEnvironmentDetected(gamescopeProcessEnvironmentHint()),
    hdrFeedbackReader(this->presentationEnvironment) {
    this->fp16AtStartup = this->config.get().global().allow_fp16;
    std::cerr << makoBuildIdentity << '\n';

    std::cerr << "MAKO Renderer: presentation policy: gamescope_wsi="
              << (this->presentationEnvironment.gamescopeWsiDisabled
                    ? "isolated" : "allowed")
              << "; hdr_exposure="
              << (this->presentationEnvironment.hdrExposureDisabled
                    ? "disabled" : "allowed")
              << "; gamescope_process_hint="
              << (this->gamescopeEnvironmentDetected ? "present" : "absent")
              << '\n';

    const auto initialHdrFeedback =
        this->hdrFeedbackReader.diagnosticSample();
    this->lastHdrFeedbackSample = initialHdrFeedback.active;
    this->lastHdrActivationSource = initialHdrFeedback.activationSource;
    this->gamescopeDetected = initialHdrFeedback.gamescopeDetected;
    if (const auto target = confirmedGamescopePresentationTarget(
            initialHdrFeedback)) {
        this->gamescopePresentationTarget = VkExtent2D{
            .width = target->width,
            .height = target->height,
        };
    }
    this->lastGamescopeRefreshHz = initialHdrFeedback.refreshHz;
    this->gamescopeRefreshHz = initialHdrFeedback.refreshHz;
    this->gamescopePresentationFeedback = initialHdrFeedback.presentation;
    this->lastHdrFeedbackDiagnosticKey = hdrFeedbackDiagnosticKey(
        initialHdrFeedback
    );
    // Gamescope's per-application root properties can still describe the
    // previous held commit while a new process creates its first swapchain, so
    // those values retain the settling window. Output HDR capability is logged
    // separately and never promoted to application HDR intent.
    this->gamescopeHdrActive = initialGamescopeHdrActivation(
        initialHdrFeedback
    );
    this->hdrFeedback.seed(this->gamescopeHdrActive);
    this->lastHdrFeedbackPoll = std::chrono::steady_clock::now();
    if (this->gamescopeHdrActive) {
        std::cerr << "MAKO Renderer: Gamescope application HDR feedback initialized: active="
                  << *this->gamescopeHdrActive
                  << "; display=" << initialHdrFeedback.display
                  << "; refresh_hz="
                  << initialHdrFeedback.refreshHz.value_or(0)
                  << "; presentation_target="
                  << initialHdrFeedback.outputWidth.value_or(0) << 'x'
                  << initialHdrFeedback.outputHeight.value_or(0)
                  << "; activation_source="
                  << (initialHdrFeedback.activationSource.empty()
                        ? "unavailable" : initialHdrFeedback.activationSource)
                  << '\n';
    } else {
        std::cerr << "MAKO Renderer: Gamescope application HDR feedback provisional; "
                     "normalized 10-bit swapchains use real-frame passthrough until confirmed; "
                  << "reason=" << initialHdrFeedback.status
                  << " display="
                  << (initialHdrFeedback.display.empty()
                        ? "(unset)" : initialHdrFeedback.display)
                  << "; resolver=" << initialHdrFeedback.resolverStatus
                  << "; activation_source="
                  << (initialHdrFeedback.activationSource.empty()
                        ? "unavailable" : initialHdrFeedback.activationSource)
                  << "; output_hdr=";
        if (initialHdrFeedback.outputHdrEnabled)
            std::cerr << (*initialHdrFeedback.outputHdrEnabled ? 1 : 0);
        else
            std::cerr << "unknown";
        std::cerr << "; app_hdr_metadata="
                  << (initialHdrFeedback.appHdrMetadataPresent ? 1 : 0)
                  << "; gamescope_pid="
                  << initialHdrFeedback.gamescopePid.value_or(UINT32_MAX)
                  << "; server_id="
                  << initialHdrFeedback.xwaylandServerId.value_or(UINT32_MAX)
                  << "; presentation_target="
                  << initialHdrFeedback.outputWidth.value_or(0) << 'x'
                  << initialHdrFeedback.outputHeight.value_or(0)
                  << "; candidates="
                  << (initialHdrFeedback.resolverCandidates.empty()
                        ? "(none)" : initialHdrFeedback.resolverCandidates)
                  << '\n';
    }
    logHdrFeedbackDiagnostic(
        "MAKO Renderer: Gamescope presentation feedback initialized: ",
        initialHdrFeedback
    );

    // find active profile
    const auto identification = ls::identify();
    const auto& profile = findProfile(this->config.get(), identification);
    if (present_diagnostics::enabled()) {
        const auto overlayLibraries = present_diagnostics::steamOverlayLibraries();
        std::cerr << "MAKO Renderer: present diagnostics: "
                     "operation=process-identity"
                  << " pid=" << ::getpid()
                  << " executable="
                  << diagnosticToken(identification.executable)
                  << " wine_executable="
                  << diagnosticToken(
                         identification.wine_executable.value_or("")
                     )
                  << " process_name="
                  << diagnosticToken(identification.process_name)
                  << " profile="
                  << diagnosticToken(
                         profile ? profile->second.name : "(none)"
                     )
                  << " identification="
                  << (profile
                        ? identificationToken(profile->first) : "none")
                  << " build=" << MAKO_BUILD_VERSION
                  << " fingerprint=" << MAKO_BUILD_FINGERPRINT
                  << " steam_overlay_hook_loaded=" << overlayLibraries.hookLoaded
                  << " steam_overlay_vulkan_loaded=" << overlayLibraries.vulkanLoaded
                  << '\n';
    }
    if (!profile.has_value()) {
        this->publishSurfaceScalingPolicy();
        return;
    }

    this->active_profile = profileForLayer(profile->second);
    // Frame Generation provisioning is a process-start choice because LSFG
    // needs application-device interop. The separate execution switch remains
    // live: 0x performs no generation work while 2x-5x or Adaptive can reuse
    // already provisioned backend and private resources in place.
    this->frameGenerationInteropProvisionedAtStartup =
        frameGenerationLayer &&
        this->active_profile->frame_generation_provisioned;
    this->scalingEngineConfiguredAtStartup =
        this->active_profile->scaling_enabled;
    this->swapchainImageCountCompatibilityConfiguredAtStartup =
        this->active_profile->swapchain_image_count_compatibility;
    this->mailboxPresentationCompatibilityConfiguredAtStartup =
        this->active_profile->mailbox_presentation_compatibility;

    std::cerr << "MAKO Renderer: using profile with name '" << this->active_profile->name << "' ";
    switch (profile->first) {
        case ls::IdentType::OVERRIDE:
            std::cerr << "(identified via override)\n";
            break;
        case ls::IdentType::EXECUTABLE:
            std::cerr << "(identified via executable)\n";
            break;
        case ls::IdentType::WINE_EXECUTABLE:
            std::cerr << "(identified via wine executable)\n";
            break;
        case ls::IdentType::PROCESS_NAME:
            std::cerr << "(identified via process name)\n";
            break;
        case ls::IdentType::FALLBACK:
            std::cerr << "(identified via fallback)\n";
            break;
    }
    if (this->active_profile->ultra_performance) {
        std::cerr << "MAKO Renderer: Ultra Performance active: flow_scale="
                  << ls::effectiveFlowScale(*this->active_profile)
                  << "; lighter_model="
                  << ls::effectivePerformanceMode(*this->active_profile)
                  << "; resources=active-policy"
                  << "; compatible_profile_reload=live\n";
    }
    if (this->active_profile->swapchain_image_count_compatibility) {
        std::cerr << "MAKO Renderer: Game Swapchain Images compatibility "
                     "active: policy=application-minimum; lifetime=process; "
                     "generated-headroom=disabled\n";
    }
    if (this->active_profile->mailbox_presentation_compatibility) {
        std::cerr << "MAKO Renderer: Mailbox Presentation compatibility "
                     "active: policy=mailbox-when-supported; "
                     "lifetime=process; ordered-fifo=disabled\n";
    }
    this->publishSurfaceScalingPolicy();
}

ConfigurationUpdateResult Root::update(const bool forceConfigurationPoll) {
    ConfigurationUpdateResult result;
    const auto now = std::chrono::steady_clock::now();
    constexpr auto hdrFeedbackPollInterval = std::chrono::milliseconds(250);
    if (!this->lastHdrFeedbackPoll ||
            now - *this->lastHdrFeedbackPoll >= hdrFeedbackPollInterval) {
        const auto hdrFeedbackSample =
            this->hdrFeedbackReader.diagnosticSample();
        this->gamescopeFocus = hdrFeedbackSample.focus;
        for (auto& [swapchain, context] : this->swapchains) {
            static_cast<void>(swapchain);
            context.updateGamescopeFocus(this->gamescopeFocus);
        }
        this->lastHdrFeedbackSample = hdrFeedbackSample.active;
        this->lastHdrActivationSource = hdrFeedbackSample.activationSource;
        this->gamescopeDetected = hdrFeedbackSample.gamescopeDetected;
        const auto presentationFeedback =
            mergeGamescopePresentationFeedback(
                this->gamescopePresentationFeedback,
                hdrFeedbackSample.presentation
            );
        if (presentationFeedback != this->gamescopePresentationFeedback) {
            this->gamescopePresentationFeedback = presentationFeedback;
            for (auto& [swapchain, context] : this->swapchains) {
                static_cast<void>(swapchain);
                context.updateGamescopePresentationFeedback(
                    this->gamescopePresentationFeedback
                );
            }
        }
        this->gamescopePresentationTarget.reset();
        if (const auto target = confirmedGamescopePresentationTarget(
                hdrFeedbackSample)) {
            this->gamescopePresentationTarget = VkExtent2D{
                .width = target->width,
                .height = target->height,
            };
        }
        if (hdrFeedbackSample.refreshHz != this->lastGamescopeRefreshHz) {
            this->lastGamescopeRefreshHz = hdrFeedbackSample.refreshHz;
            this->gamescopeRefreshHz = hdrFeedbackSample.refreshHz;
            result.refreshRateChanged = true;
            for (auto& [swapchain, context] : this->swapchains) {
                static_cast<void>(swapchain);
                context.updateGamescopeRefreshRate(this->gamescopeRefreshHz);
            }
        }
        const auto diagnosticKey = hdrFeedbackDiagnosticKey(hdrFeedbackSample);
        if (diagnosticKey != this->lastHdrFeedbackDiagnosticKey) {
            this->lastHdrFeedbackDiagnosticKey = diagnosticKey;
            logHdrFeedbackDiagnostic(
                "MAKO Renderer: Gamescope application HDR feedback status: ",
                hdrFeedbackSample
            );
        }
        this->lastHdrFeedbackPoll = now;
    }

    if (const auto changed = this->hdrFeedback.observe(
            this->lastHdrFeedbackSample, now)) {
        this->gamescopeHdrActive = changed;
        this->runtimeStateRevision++;
        result.hdrFeedbackChanged = true;
        for (auto& [swapchain, context] : this->swapchains) {
            static_cast<void>(swapchain);
            if (!this->presentationEnvironment.gamescopeWsiDisabled &&
                    context.updateGamescopeHdrState(
                    *changed, this->runtimeStateRevision))
                result.hdrContextsDeferred++;
        }
        std::cerr << "MAKO Renderer: Gamescope application HDR feedback stabilized: active="
                  << *changed
                  << "; activation_source="
                  << (this->lastHdrActivationSource.empty()
                        ? "unavailable" : this->lastHdrActivationSource)
                  << "; contexts_pending_private_transition="
                  << result.hdrContextsDeferred << '\n';
    }

    this->publishSurfaceScalingPolicy();

    // Configuration hot reload does not need a filesystem metadata query for
    // every presented frame. Keep the UI responsive while bounding the check
    // to four times per second, matching the feedback sampling cadence.
    constexpr auto configurationPollInterval = std::chrono::milliseconds(250);
    if (!forceConfigurationPoll && this->lastConfigurationPoll &&
            now - *this->lastConfigurationPoll < configurationPollInterval)
        return result;
    this->lastConfigurationPoll = now;

    if (!this->config.update())
        return result;

    result.reloaded = true;
    const auto& currentGlobal = this->config.get().global();
    result.globalChangeDeferred = backendGlobalChangePending(
        this->backendGlobal, currentGlobal
    ) || currentGlobal.allow_fp16 != this->fp16AtStartup;

    const auto previousProfileName = this->active_profile
        ? std::optional<std::string>{this->active_profile->name}
        : std::nullopt;
    const auto& profile = findProfile(this->config.get(), ls::identify());
    auto requestedProfile = profile
        ? std::optional<ls::GameConf>{profileForLayer(profile->second)}
        : std::nullopt;
    const bool activeUltraPerformance = this->active_profile &&
        this->active_profile->ultra_performance;
    const bool requestedUltraPerformance = requestedProfile &&
        requestedProfile->ultra_performance;

    auto runtimeProfile = requestedProfile;
    // A saved model that could not start stays saved, and it asks this process
    // for nothing because only a restart can try it again.
    if (runtimeProfile && this->backendProfile &&
            runtimeProfile->frame_generation_model ==
                this->frameGenerationModelFallbackFrom) {
        runtimeProfile->frame_generation_model =
            this->backendProfile->frame_generation_model;
    }
    bool profileProcessRestartRequired = false;
    bool gpuSelectionPending = false;
    bool frameGenerationModelPending = false;
    bool frameGenerationProvisioningPending = false;
    bool ultraPerformancePending =
        activeUltraPerformance != requestedUltraPerformance;
    bool scalingEnginePending = false;
    bool swapchainImageCountCompatibilityPending = false;
    bool mailboxPresentationCompatibilityPending = false;
    if (runtimeProfile && this->active_profile) {
        auto projection = projectProcessStaticProfileForLiveUpdate(
            *this->active_profile, *runtimeProfile,
            this->frameGenerationInteropProvisionedAtStartup,
            this->scalingEngineConfiguredAtStartup,
            this->swapchainImageCountCompatibilityConfiguredAtStartup,
            this->mailboxPresentationCompatibilityConfiguredAtStartup
        );
        *runtimeProfile = std::move(projection.runtimeProfile);
        gpuSelectionPending = projection.gpuSelectionPending;
        frameGenerationModelPending = projection.frameGenerationModelPending;
        frameGenerationProvisioningPending =
            projection.frameGenerationProvisioningPending;
        ultraPerformancePending = projection.ultraPerformancePending;
        scalingEnginePending = projection.scalingEnginePending;
        swapchainImageCountCompatibilityPending =
            projection.swapchainImageCountCompatibilityPending;
        mailboxPresentationCompatibilityPending =
            projection.mailboxPresentationCompatibilityPending;
        profileProcessRestartRequired = projection.restartRequired() ||
            currentGlobal.allow_fp16 != this->fp16AtStartup;
    } else if (runtimeProfile) {
        if (runtimeProfile->frame_generation_provisioned !=
                this->frameGenerationInteropProvisionedAtStartup) {
            runtimeProfile->frame_generation_provisioned =
                this->frameGenerationInteropProvisionedAtStartup;
            frameGenerationProvisioningPending = true;
            profileProcessRestartRequired = true;
        }
        if (runtimeProfile->scaling_enabled !=
                this->scalingEngineConfiguredAtStartup) {
            runtimeProfile->scaling_enabled =
                this->scalingEngineConfiguredAtStartup;
            scalingEnginePending = true;
            profileProcessRestartRequired = true;
        }
        if (runtimeProfile->swapchain_image_count_compatibility !=
                this->swapchainImageCountCompatibilityConfiguredAtStartup) {
            runtimeProfile->swapchain_image_count_compatibility =
                this->swapchainImageCountCompatibilityConfiguredAtStartup;
            swapchainImageCountCompatibilityPending = true;
            profileProcessRestartRequired = true;
        }
        if (runtimeProfile->mailbox_presentation_compatibility !=
                this->mailboxPresentationCompatibilityConfiguredAtStartup) {
            runtimeProfile->mailbox_presentation_compatibility =
                this->mailboxPresentationCompatibilityConfiguredAtStartup;
            mailboxPresentationCompatibilityPending = true;
            profileProcessRestartRequired = true;
        }
    }
    if (frameGenerationModelPending)
        std::cerr << "MAKO Renderer: model change pending; restart the game to select the saved frame generation model\n";
    if (frameGenerationProvisioningPending) {
        std::cerr << "MAKO Renderer: Frame Generation provisioning toggle "
                     "deferred; restart the game to change LSFG device "
                     "interop and backend ownership; 0x and compatible "
                     "profile changes remain live\n";
    }
    if (ultraPerformancePending) {
        profileProcessRestartRequired = true;
        std::cerr << "MAKO Renderer: Ultra Performance toggle deferred; "
                     "restart the game to apply its model and "
                     "resource policy; compatible profile changes remain live\n";
    }
    if (scalingEnginePending) {
        std::cerr << "MAKO Renderer: Scaling Engine toggle deferred; restart "
                     "the game to rebuild the process Vulkan layer chain; "
                     "method and tuning changes remain live\n";
    }
    if (swapchainImageCountCompatibilityPending) {
        std::cerr << "MAKO Renderer: Game Swapchain Images compatibility "
                     "toggle deferred; restart the game to change its WSI "
                     "image-count contract\n";
    }
    if (mailboxPresentationCompatibilityPending) {
        std::cerr << "MAKO Renderer: Mailbox Presentation compatibility "
                     "toggle deferred; restart the game to change its WSI "
                     "present-mode contract\n";
    }
    if (profileProcessRestartRequired) {
        result.processRestartDeferredContexts += this->swapchains.size();
        result.processProfileChangeDeferred = true;
    }

    this->runtimeStateRevision++;
    if (profileProcessRestartRequired && present_diagnostics::enabled()) {
        for (const auto& [swapchain, context] : this->swapchains) {
            static_cast<void>(swapchain);
            std::cerr << "MAKO Renderer: present diagnostics: "
                         "operation=runtime-transition-pending"
                      << " context=" << context.diagnosticsId()
                      << " state_revision=" << this->runtimeStateRevision
                      << " reason=process-static-profile"
                      << " frame_generation_model_pending=" << frameGenerationModelPending
                      << " gpu_selection_pending=" << gpuSelectionPending
                      << " frame_generation_provisioning_pending="
                      << frameGenerationProvisioningPending
                      << " ultra_performance_pending="
                      << ultraPerformancePending
                      << " scaling_engine_pending="
                      << scalingEnginePending
                      << " swapchain_image_count_compatibility_pending="
                      << swapchainImageCountCompatibilityPending
                      << " mailbox_presentation_compatibility_pending="
                      << mailboxPresentationCompatibilityPending
                      << " action=wait-for-process-restart\n";
        }
    }
    if (runtimeProfile)
        this->active_profile = std::move(*runtimeProfile);
    else
        this->active_profile = std::nullopt;
    for (const auto& device : this->gpuLoadDevices) {
        try {
            device.monitor->setEnabled(this->active_profile &&
                this->active_profile->frame_generation_enabled &&
                this->active_profile->gpu_headroom_percent > 0);
        } catch (...) { device.monitor->setEnabled(false); }
    }
    this->publishSurfaceScalingPolicy();

    const auto currentProfileName = this->active_profile
        ? std::optional<std::string>{this->active_profile->name}
        : std::nullopt;
    if (previousProfileName != currentProfileName) {
        std::cerr << "MAKO Renderer: live profile selection changed: previous='"
                  << previousProfileName.value_or("(none)")
                  << "' current='"
                  << currentProfileName.value_or("(none)") << "'";
        if (profile.has_value()) {
            switch (profile->first) {
                case ls::IdentType::OVERRIDE:
                    std::cerr << " source=override";
                    break;
                case ls::IdentType::EXECUTABLE:
                    std::cerr << " source=executable";
                    break;
                case ls::IdentType::WINE_EXECUTABLE:
                    std::cerr << " source=wine-executable";
                    break;
                case ls::IdentType::PROCESS_NAME:
                    std::cerr << " source=process-name";
                    break;
                case ls::IdentType::FALLBACK:
                    std::cerr << " source=fallback";
                    break;
            }
        }
        std::cerr << '\n';
    }

    if (this->active_profile) {
        const auto contextProfile =
            profileForLayerContext(*this->active_profile);
        for (auto& [swapchain, context] : this->swapchains) {
            static_cast<void>(swapchain);
            const auto update = context.updateProfile(
                contextProfile, this->runtimeStateRevision,
                requestedProfile ? &*requestedProfile : nullptr,
                profileProcessRestartRequired
            );
            if (update.action == ProfileUpdateAction::ApplyLive)
                result.liveContextsUpdated++;
            if (update.swapchainRecreationDeferred)
                result.swapchainRecreationDeferredContexts++;
            if (update.processRestartDeferred)
                result.processRestartDeferredContexts++;
            if (update.swapchainRecreationRequested)
                result.recreationRequestedContexts++;
        }
        result.processProfileChangeDeferred =
            result.processProfileChangeDeferred ||
            (requestedProfile && backendProfileChangePending(
                this->backendProfile, *requestedProfile,
                this->frameGenerationModelFallbackFrom
            ));
        if (result.processProfileChangeDeferred) {
            result.processRestartDeferredContexts = std::max(
                result.processRestartDeferredContexts,
                this->swapchains.size()
            );
        }
    } else {
        // Losing the active profile must stop generation immediately, but it
        // does not require destroying any in-flight Vulkan resources.
        for (auto& [swapchain, context] : this->swapchains) {
            static_cast<void>(swapchain);
            context.disableFrameGeneration();
            result.liveContextsUpdated++;
        }
    }

    return result;
}

void Root::modifyInstanceCreateInfo(VkInstanceCreateInfo& createInfo,
        const std::function<void(void)>& finish) const {
    if (!this->frameGenerationInteropProvisioned() && !this->scalingEngineProvisioned() &&
            !this->scalingSurfaceConnectionProvisioned()) {
        finish();
        return;
    }

    std::vector<const char*> requiredExtensions{"VK_KHR_get_physical_device_properties2"};
    if (this->frameGenerationInteropProvisioned()) {
        requiredExtensions.push_back("VK_KHR_external_memory_capabilities");
        requiredExtensions.push_back("VK_KHR_external_semaphore_capabilities");
    }
    auto extensions = add_extensions(
        createInfo.ppEnabledExtensionNames,
        createInfo.enabledExtensionCount,
        requiredExtensions
    );
    createInfo.enabledExtensionCount = static_cast<uint32_t>(extensions.size());
    createInfo.ppEnabledExtensionNames = extensions.data();

    finish();
}

void Root::modifyDeviceCreateInfo(VkDeviceCreateInfo& createInfo,
        const char* const swapchainMaintenance1Extension,
        const bool gamescopeDisplayTiming,
        const std::function<void(void)>& finish) const {
    const bool frameGenerationInterop = this->frameGenerationInteropProvisioned();
    if (!frameGenerationInterop && !swapchainMaintenance1Extension &&
            !gamescopeDisplayTiming) {
        finish();
        return;
    }

    std::vector<const char*> requiredExtensions;
    if (frameGenerationInterop) {
        requiredExtensions = {
            "VK_KHR_external_memory",
            "VK_KHR_external_memory_fd",
            "VK_KHR_external_semaphore",
            "VK_KHR_external_semaphore_fd",
            "VK_KHR_timeline_semaphore"
        };
    }
    if (swapchainMaintenance1Extension)
        requiredExtensions.push_back(swapchainMaintenance1Extension);
    if (gamescopeDisplayTiming)
        requiredExtensions.push_back(VK_GOOGLE_DISPLAY_TIMING_EXTENSION_NAME);
    auto extensions = add_extensions(
        createInfo.ppEnabledExtensionNames,
        createInfo.enabledExtensionCount,
        requiredExtensions
    );
    createInfo.enabledExtensionCount = static_cast<uint32_t>(extensions.size());
    createInfo.ppEnabledExtensionNames = extensions.data();

    bool timelineFeatureEnabled = false;
    bool swapchainMaintenance1FeatureEnabled = false;
    auto* featureInfo = reinterpret_cast<VkBaseInStructure*>(const_cast<void*>(createInfo.pNext));
    while (featureInfo) {
        if (featureInfo->sType ==
                    VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES) {
            auto* features = reinterpret_cast<VkPhysicalDeviceVulkan12Features*>(featureInfo);
            if (frameGenerationInterop)
                features->timelineSemaphore = VK_TRUE;
            timelineFeatureEnabled = features->timelineSemaphore == VK_TRUE;
        } else if (featureInfo->sType ==
                    VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_TIMELINE_SEMAPHORE_FEATURES) {
            auto* features = reinterpret_cast<VkPhysicalDeviceTimelineSemaphoreFeatures*>(featureInfo);
            if (frameGenerationInterop)
                features->timelineSemaphore = VK_TRUE;
            timelineFeatureEnabled = features->timelineSemaphore == VK_TRUE;
        } else if (featureInfo->sType ==
                VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SWAPCHAIN_MAINTENANCE_1_FEATURES_EXT) {
            auto* features = reinterpret_cast<
                VkPhysicalDeviceSwapchainMaintenance1FeaturesEXT*>(
                    featureInfo
                );
            if (swapchainMaintenance1Extension)
                features->swapchainMaintenance1 = VK_TRUE;
            swapchainMaintenance1FeatureEnabled =
                features->swapchainMaintenance1 == VK_TRUE;
        }

        featureInfo = const_cast<VkBaseInStructure*>(featureInfo->pNext);
    }

    VkPhysicalDeviceTimelineSemaphoreFeatures timelineFeatures{
        .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_TIMELINE_SEMAPHORE_FEATURES,
        .pNext = const_cast<void*>(createInfo.pNext),
        .timelineSemaphore = VK_TRUE
    };
    if (frameGenerationInterop && !timelineFeatureEnabled)
        createInfo.pNext = &timelineFeatures;

    VkPhysicalDeviceSwapchainMaintenance1FeaturesEXT maintenance1Features{
        .sType =
            VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SWAPCHAIN_MAINTENANCE_1_FEATURES_EXT,
        .pNext = const_cast<void*>(createInfo.pNext),
        .swapchainMaintenance1 = VK_TRUE,
    };
    if (swapchainMaintenance1Extension &&
            !swapchainMaintenance1FeatureEnabled) {
        createInfo.pNext = &maintenance1Features;
    }

    finish();
}

SwapchainCreateModification Root::modifySwapchainCreateInfo(const vk::Vulkan& vk,
        VkSwapchainCreateInfoKHR& createInfo,
        const std::optional<SpatialScalingExtents>& previousVariableExtents,
        const std::optional<SpatialScalingExtents>&
            variableSurfaceRollbackExtents,
        const std::optional<FixedSurfaceScalingContract>& fixedSurfaceContract,
        const bool spatialSurfaceScalingSupported,
        const bool gamescopeScalingSurface,
        const bool offscreenX11Surface,
        const std::function<void(
            const FixedSurfaceScalingContract&)>& publishSpatialCreate,
        const std::function<void(void)>& finish) const {
    SwapchainCreateModification modification{
        .applicationExtent = createInfo.imageExtent,
        .presentationExtent = createInfo.imageExtent,
        .gamescopePresentationTarget = this->gamescopePresentationTarget,
    };
    if (!this->active_profile.has_value()) {
        finish();
        return modification;
    }

    VkSurfaceCapabilitiesKHR caps{}; // NOLINT (enum value 0)
    auto res = vk.fi().GetPhysicalDeviceSurfaceCapabilitiesKHR(
        vk.physdev(), createInfo.surface, &caps);
    if (res != VK_SUCCESS)
        throw ls::vulkan_error(res, "vkGetPhysicalDeviceSurfaceCapabilitiesKHR() failed");
    modification.surfaceMinImageCount = caps.minImageCount;

    // In the managed render -> Gamescope WSI -> spatial chain, the lower
    // capability owner deliberately returns the virtual source extent. The
    // current upper resource owner must validate create-time state against
    // the relayed compositor presentation extent before expanding the source
    // request. An unrelated extent remains unchanged and fails closed below.
    if (spatialScalingCapabilityRelayByLayer() &&
            spatialScalingOwnedByLayer() && fixedSurfaceContract) {
        static_cast<void>(prepareFixedSurfaceCapabilityRelay(
            caps, *fixedSurfaceContract
        ));
    }

    modification.variableSurface = !fixedSurfaceExtent(caps.currentExtent);

    VkPhysicalDeviceMemoryBudgetPropertiesEXT liveMemoryBudget{
        .sType =
            VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_MEMORY_BUDGET_PROPERTIES_EXT,
    };
    VkPhysicalDeviceMemoryProperties2 memoryProperties2{
        .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_MEMORY_PROPERTIES_2,
    };
    const bool liveMemoryBudgetAvailable =
        vk.fi().GetPhysicalDeviceMemoryProperties2 &&
        physicalDeviceSupportsExtension(
            vk.fi(), vk.physdev(), VK_EXT_MEMORY_BUDGET_EXTENSION_NAME
        );
    if (liveMemoryBudgetAvailable) {
        memoryProperties2.pNext = &liveMemoryBudget;
        vk.fi().GetPhysicalDeviceMemoryProperties2(
            vk.physdev(), &memoryProperties2
        );
    } else {
        vk.fi().GetPhysicalDeviceMemoryProperties(
            vk.physdev(), &memoryProperties2.memoryProperties
        );
    }
    const auto memoryAdmission = variablePresentationMemoryAdmission(
        memoryProperties2.memoryProperties,
        liveMemoryBudgetAvailable ? &liveMemoryBudget : nullptr
    );
    const auto colorPipeline = classifySwapchainColor(
        createInfo.imageFormat, createInfo.imageColorSpace,
        (!this->presentationEnvironment.gamescopeWsiDisabled &&
            this->gamescopeHdrActive.value_or(false))
    );
    const auto contextProfile = profileForLayerContext(*this->active_profile);
    // Generated frames cannot reach the screen through Wine's offscreen copy.
    modification.frameGenerationSurfaceUnavailable = offscreenX11Surface;
    const bool frameGenerationAvailable =
        frameGenerationInteropForLayer(vk.frameGenerationInteropEnabled()) &&
        !offscreenX11Surface;
    const auto displayResizePolicyForSource = [&](const VkExtent2D source) {
        return bridgeDisplayResizePolicy(
            contextProfile,
            gamescopeScalingSurface && modification.variableSurface &&
                spatialScalingOwnedByLayer() && spatialScalingCapabilityOwnedByLayer(),
            !this->presentationEnvironment.hdrExposureDisabled,
            frameGenerationAvailable,
            source, this->gamescopePresentationTarget
        );
    };
    const auto displayResizePolicy =
        displayResizePolicyForSource(createInfo.imageExtent);
    // Window-mode changes can briefly request the display's native extent.
    // Keep the smaller, already allocated split across that exact-output
    // hop so returning to it is not priced as a cold allocation. Never invent
    // proof from a native-only launch or retain it across a display change.
    modification.retainVariableSurfacePresentationProof =
        spatialSurfaceScalingSupported && modification.variableSurface &&
        previousVariableExtents && this->gamescopePresentationTarget &&
        ((ls::spatialScalingRequested(contextProfile) &&
            !contextProfile.scaling_supersampling) ||
            displayResizePolicyForSource(previousVariableExtents->source).has_value()) &&
        sameExtent(previousVariableExtents->presentation,
            *this->gamescopePresentationTarget) &&
        sameExtent(createInfo.imageExtent, *this->gamescopePresentationTarget);
    modification.swapchainImageCountCompatibility =
        contextProfile.swapchain_image_count_compatibility;
    auto prospectiveCreateInfo = createInfo;
    static_cast<void>(context_ModifySwapchainCreateInfo(
        contextProfile,
        caps.maxImageCount,
        prospectiveCreateInfo,
        (!this->presentationEnvironment.gamescopeWsiDisabled &&
            this->gamescopeHdrActive.value_or(false)),
        this->gamescopeDetected,
        this->presentationEnvironment,
        frameGenerationAvailable,
        displayResizePolicy.has_value()
    ));
    auto policySnapshot = this->surfaceScalingPolicySnapshot();
    if (displayResizePolicy)
        policySnapshot.policy = *displayResizePolicy;
    const auto postFrameGenerationAdmission =
        variablePresentationResourceAdmission(
            memoryAdmission,
            createInfo.imageExtent,
            createInfo.imageFormat,
            prospectiveCreateInfo.minImageCount,
            generatedFrameCapacityForProfile(*this->active_profile)
        );
    const auto preFrameGenerationAdmission =
        variablePresentationResourceAdmission(
            memoryAdmission,
            createInfo.imageExtent,
            createInfo.imageFormat,
            prospectiveCreateInfo.minImageCount,
            generatedFrameCapacityForProfile(*this->active_profile),
            SpatialFramePipelinePlacement::PreFrameGeneration
        );
    const VariablePresentationPixelBudgets presentationPixelBudgets{
        .preFrameGeneration = preFrameGenerationAdmission.effectivePixelBudget,
        .postFrameGeneration = postFrameGenerationAdmission.effectivePixelBudget,
        // Source growth is charged at the conservative combined-resource
        // rate, never at the cheaper output-only WSI bytes-per-pixel rate.
        .sourceGrowth = memoryAdmission.effectivePixelBudget,
    };
    const bool spatialCapabilityRelay =
        spatialScalingCapabilityRelayByLayer();
    const bool spatialResourceOwner = spatialScalingOwnedByLayer();
    const bool spatialExtentOwner =
        spatialScalingCapabilityOwnedByLayer();
    const bool gamescopePresentationTargetRequired =
        spatialExtentOwner && (splitLayerChainEnabled() || gamescopeScalingSurface) &&
        (this->gamescopeEnvironmentDetected || this->gamescopeDetected);
    if (!spatialResourceOwner && !spatialExtentOwner) {
        // The legacy upper split role relays capabilities but neither expands
        // the lower swapchain nor allocates reconstruction resources.
        policySnapshot.policy.enabled = false;
    }
    auto scalingDecision = spatialSurfaceScalingSupported
        ? scalingDecisionForCreate(
            policySnapshot.policy,
            policySnapshot.processSupported,
            policySnapshot.revision,
            caps,
            createInfo.imageExtent,
            previousVariableExtents,
            fixedSurfaceContract,
            presentationPixelBudgets,
            this->gamescopePresentationTarget,
            gamescopePresentationTargetRequired,
            memoryAdmission.staticPixelBudget,
            variableSurfaceRollbackExtents
        )
        : SpatialScalingCreateDecision{
            .inactiveReason = SpatialScalingInactiveReason::
                GamescopeWsiSurfaceUnproven,
        };
    if (displayResizePolicy && scalingDecision.extents && !sameExtent(
            scalingDecision.extents->presentation, *this->gamescopePresentationTarget)) {
        // Do not substitute a partial resize when the display-sized request
        // exceeds the existing surface or memory envelope.
        scalingDecision.extents.reset();
        scalingDecision.inactiveReason = SpatialScalingInactiveReason::VariableSurfaceNoHeadroom;
    }
    const auto& scalingExtents = scalingDecision.extents;
    modification.variableFeedbackSuppressed =
        scalingDecision.inactiveReason ==
            SpatialScalingInactiveReason::VariableSurfaceFeedback;
    modification.spatialScalingMemoryConstrained =
        scalingDecision.memoryBudgetConstrained;
    const bool fixedVirtualSourceRequest =
        fixedSurfaceExtent(caps.currentExtent) &&
        !sameExtent(createInfo.imageExtent, caps.currentExtent);
    const bool supportedScalingEncoding =
        spatialScalingColorSupported(colorPipeline) &&
        !(colorPipeline.hdr && this->presentationEnvironment.hdrExposureDisabled);
    VkBool32 queueFamilySupportsPresentation = VK_FALSE;
    const bool queueSurfaceSupportChecked =
        scalingExtents && vk.fi().GetPhysicalDeviceSurfaceSupportKHR;
    if (scalingExtents && vk.fi().GetPhysicalDeviceSurfaceSupportKHR) {
        const auto surfaceSupportResult =
            vk.fi().GetPhysicalDeviceSurfaceSupportKHR(
                vk.physdev(), vk.queueFamilyIndex(), createInfo.surface,
                &queueFamilySupportsPresentation
            );
        if (surfaceSupportResult != VK_SUCCESS) {
            throw ls::vulkan_error(
                surfaceSupportResult,
                "vkGetPhysicalDeviceSurfaceSupportKHR() failed"
            );
        }
    }
    const bool spatialShapeSupported =
        spatialScalingSwapchainShapeSupported(createInfo);
    const bool spatialQueueCommandsSupported = vk.queueFamilySupports(
        VK_QUEUE_GRAPHICS_BIT | VK_QUEUE_COMPUTE_BIT
    );
    const bool spatialFormatSupported =
        supportedScalingEncoding &&
        (caps.supportedUsageFlags & (
            VK_IMAGE_USAGE_TRANSFER_SRC_BIT |
            VK_IMAGE_USAGE_TRANSFER_DST_BIT
        )) == (
            VK_IMAGE_USAGE_TRANSFER_SRC_BIT |
            VK_IMAGE_USAGE_TRANSFER_DST_BIT
        ) &&
        vk.supportsOptimalTilingFormatFeatures(
            createInfo.imageFormat,
            VK_FORMAT_FEATURE_BLIT_SRC_BIT |
                VK_FORMAT_FEATURE_BLIT_DST_BIT
        ) &&
        vk.supportsOptimalTilingFormatFeatures(
            colorPipeline.exchangeFormat,
            VK_FORMAT_FEATURE_BLIT_SRC_BIT |
                VK_FORMAT_FEATURE_BLIT_DST_BIT |
                VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT |
                VK_FORMAT_FEATURE_SAMPLED_IMAGE_FILTER_LINEAR_BIT |
                VK_FORMAT_FEATURE_STORAGE_IMAGE_BIT
        );
    const bool spatialScalingSupported = spatialShapeSupported &&
        spatialFormatSupported && spatialQueueCommandsSupported &&
        queueFamilySupportsPresentation == VK_TRUE;
    const char* const queuePresentationSupport =
        !queueSurfaceSupportChecked ? "not-checked" :
        queueFamilySupportsPresentation == VK_TRUE
            ? "supported" : "unsupported";
    auto inactiveReason = scalingDecision.inactiveReason;
    if (scalingExtents && spatialScalingSupported) {
        modification.applicationExtent = scalingExtents->source;
        modification.presentationExtent = scalingExtents->presentation;
        modification.spatialScalingActive = spatialResourceOwner;
        if (spatialExtentOwner)
            createInfo.imageExtent = scalingExtents->presentation;
        inactiveReason = SpatialScalingInactiveReason::None;
    } else if (scalingExtents) {
        inactiveReason = !spatialShapeSupported
            ? SpatialScalingInactiveReason::SwapchainShapeUnsupported
            : (queueFamilySupportsPresentation != VK_TRUE
                ? SpatialScalingInactiveReason::QueuePresentationUnsupported
                : (!spatialQueueCommandsSupported
                    ? SpatialScalingInactiveReason::QueueCommandsUnsupported
                    : SpatialScalingInactiveReason::SwapchainFormatUnsupported));
    }
    modification.bridgeDisplayResize = displayResizePolicy.has_value();
    modification.spatialScalingInactiveReason = inactiveReason;
    modification.spatialScalingAdmissionRetryEligible =
        spatialScalingAdmissionRetryEligible(
            inactiveReason,
            previousVariableExtents,
            createInfo.imageExtent,
            policySnapshot.policy.factor,
            policySnapshot.policy.supersampling ? std::nullopt
                : this->gamescopePresentationTarget,
            policySnapshot.policy.preserveFrameGenerationSource
        );
    modification.spatialScalingPolicyRevision = policySnapshot.revision;
    modification.retainVariableSurfaceProof =
        policySnapshot.policy.enabled &&
        policySnapshot.policy.factor <= 1.0F &&
        inactiveReason == SpatialScalingInactiveReason::FactorNotUpscaling;
    if (spatialExtentOwner && !spatialResourceOwner) {
        // Publish every lower create decision, including an explicit no-split
        // result. The upper combined role must distinguish that valid native
        // decision from a missing lower DSO; otherwise a deliberate exact-
        // presentation replacement is rejected as a transient context.
        publishSpatialCreate(FixedSurfaceScalingContract{
            .extents = SpatialScalingExtents{
                .source = modification.applicationExtent,
                .presentation = modification.presentationExtent,
            },
            .factor = policySnapshot.policy.factor,
            .policyRevision = policySnapshot.revision,
            .queryGeneration = fixedSurfaceContract
                ? fixedSurfaceContract->queryGeneration : 0,
            .spatialSurfaceScalingSupported =
                spatialSurfaceScalingSupported,
            .variableSurface = modification.variableSurface,
            .memoryBudgetConstrained =
                modification.spatialScalingMemoryConstrained,
            .inactiveReason = inactiveReason,
        });
    }
    const bool awaitingLowerCreateRelay = awaitLowerSpatialCreateRelay(
        spatialCapabilityRelay,
        spatialResourceOwner,
        fixedSurfaceContract.has_value(),
        scalingExtents.has_value(),
        fixedSurfaceExtent(caps.currentExtent)
    );
    if ((this->active_profile->scaling_enabled || displayResizePolicy) &&
            (spatialResourceOwner || spatialExtentOwner) &&
            !awaitingLowerCreateRelay) {
        const auto advertised = scalingDecision.fixedContract;
        const auto admissionPlacement = scalingDecision.memoryAdmissionPlacement.
            value_or(selectSpatialFramePipelinePlacement(
                modification.applicationExtent, modification.presentationExtent,
                policySnapshot.policy.preserveFrameGenerationSource
            ));
        const auto& resourceAdmission = admissionPlacement ==
                SpatialFramePipelinePlacement::PreFrameGeneration
            ? preFrameGenerationAdmission : postFrameGenerationAdmission;
        std::ostringstream policyLog;
        policyLog << "MAKO Renderer: spatial scaling swapchain policy: "
                  << "role=" << layerRoleName
                  << "; requested=" << modification.applicationExtent.width
                  << 'x' << modification.applicationExtent.height
                  << "; surface_current=" << caps.currentExtent.width
                  << 'x' << caps.currentExtent.height
                  << "; surface_extent_mode="
                  << (modification.variableSurface ? "variable" : "fixed")
                  << "; device_local_heap_mib="
                  << (memoryAdmission.heapBytes / (1024 * 1024))
                  << "; live_memory_budget_available="
                  << liveMemoryBudgetAvailable
                  << "; device_local_heap_budget_mib="
                  << (memoryAdmission.heapBudgetBytes / (1024 * 1024))
                  << "; device_local_heap_usage_mib="
                  << (memoryAdmission.heapUsageBytes / (1024 * 1024))
                  << "; memory_reserved_headroom_mib="
                  << (memoryAdmission.reservedHeadroomBytes / (1024 * 1024))
                  << "; variable_presentation_static_pixel_budget="
                  << memoryAdmission.staticPixelBudget
                  << "; variable_presentation_live_pixel_budget="
                  << resourceAdmission.livePixelBudget.value_or(0)
                  << "; variable_presentation_pixel_budget="
                  << resourceAdmission.effectivePixelBudget
                  << "; variable_presentation_fixed_source_mib="
                  << (resourceAdmission.fixedSourceBytes / (1024 * 1024))
                  << "; variable_presentation_bytes_per_pixel="
                  << resourceAdmission.presentationBytesPerPixel
                  << "; gamescope_presentation_target="
                  << (this->gamescopePresentationTarget
                        ? this->gamescopePresentationTarget->width : 0)
                  << 'x'
                  << (this->gamescopePresentationTarget
                        ? this->gamescopePresentationTarget->height : 0)
                  << "; gamescope_presentation_target_required="
                  << gamescopePresentationTargetRequired
                  << "; gamescope_presentation_target_constrained="
                  << scalingDecision.gamescopePresentationTargetConstrained
                  << "; supersampling="
                  << policySnapshot.policy.supersampling
                  << "; gamescope_presentation_target_bypassed="
                  << scalingDecision.gamescopePresentationTargetBypassed
                  << "; advertised_source="
                  << (advertised ? advertised->extents.source.width : 0)
                  << 'x'
                  << (advertised ? advertised->extents.source.height : 0)
                  << "; advertised_presentation="
                  << (advertised ? advertised->extents.presentation.width : 0)
                  << 'x'
                  << (advertised ? advertised->extents.presentation.height : 0)
                  << "; actual_source="
                  << (fixedVirtualSourceRequest && !scalingExtents
                        ? 0 : modification.applicationExtent.width)
                  << 'x'
                  << (fixedVirtualSourceRequest && !scalingExtents
                        ? 0 : modification.applicationExtent.height)
                  << "; actual_presentation="
                  << (fixedVirtualSourceRequest && !scalingExtents
                        ? 0 : modification.presentationExtent.width)
                  << 'x'
                  << (fixedVirtualSourceRequest && !scalingExtents
                        ? 0 : modification.presentationExtent.height)
                  << "; policy_revision=" << policySnapshot.revision
                  << "; contract_policy_revision="
                  << (advertised ? advertised->policyRevision : 0)
                  << "; query_generation="
                  << (advertised ? advertised->queryGeneration : 0)
                  << "; selected_source="
                  << (scalingExtents ? scalingExtents->source.width : 0)
                  << 'x'
                  << (scalingExtents ? scalingExtents->source.height : 0)
                  << "; selected_presentation="
                  << (scalingExtents ? scalingExtents->presentation.width : 0)
                  << 'x'
                  << (scalingExtents ? scalingExtents->presentation.height : 0)
                  << "; format=" << static_cast<int>(createInfo.imageFormat)
                  << "; format_supported=" << spatialFormatSupported
                  << "; shape_supported=" << spatialShapeSupported
                  << "; queue_presentation_support="
                  << queuePresentationSupport
                  << "; queue_commands_supported="
                  << spatialQueueCommandsSupported
                  << "; variable_feedback_suppressed="
                  << modification.variableFeedbackSuppressed
                  << "; previous_presentation_budget_reused="
                  << scalingDecision.reusedPreviousPresentationBudget
                  << "; rollback_presentation_budget_reused="
                  << scalingDecision.reusedRollbackPresentationBudget
                  << "; previous_downshift_envelope_reused="
                  << scalingDecision.reusedPreviousDownshiftEnvelope
                  << "; previous_source_growth_headroom_reused="
                  << scalingDecision.reusedPreviousSourceGrowthHeadroom
                  << "; baseline_presentation_budget_used="
                  << scalingDecision.usedBaselinePresentationBudget
                  << "; extent_selected="
                  << (scalingExtents.has_value() ? 1 : 0)
                  << "; previous_fixed_source_retained="
                  << scalingDecision.retainedPreviousFixedSource
                  << "; inactive_reason="
                  << spatialScalingInactiveReasonName(inactiveReason)
                  << "; admission_retry_eligible="
                  << modification.spatialScalingAdmissionRetryEligible
                  << "; source_presentation_split="
                  << (scalingExtents && !sameExtent(
                        scalingExtents->source,
                        scalingExtents->presentation
                      ) ? 1 : 0)
                  << "; active=" << modification.spatialScalingActive;
        std::cerr << policyLog.str() << '\n';
        if (scalingDecision.retainedPreviousFixedSource && scalingExtents) {
            std::cerr << "MAKO Renderer: fixed-surface scaling factor "
                         "constrained: requested_factor="
                      << policySnapshot.policy.factor
                      << "; retained_source="
                      << scalingExtents->source.width << 'x'
                      << scalingExtents->source.height
                      << "; presentation="
                      << scalingExtents->presentation.width << 'x'
                      << scalingExtents->presentation.height
                      << "; reason=wsi-source-unchanged"
                      << "; action=retain-proven-split\n";
        }
        if (modification.variableFeedbackSuppressed &&
                previousVariableExtents) {
            std::cerr << "MAKO Renderer: spatial scaling variable-surface "
                         "feedback guard: surface=" << createInfo.surface
                      << "; previous_source="
                      << previousVariableExtents->source.width << 'x'
                      << previousVariableExtents->source.height
                      << "; previous_presentation="
                      << previousVariableExtents->presentation.width << 'x'
                      << previousVariableExtents->presentation.height
                      << "; requested="
                      << modification.applicationExtent.width << 'x'
                      << modification.applicationExtent.height
                      << "; action=native-feedback-guard\n";
        }
    }

    if (spatialCapabilityRelay && !spatialResourceOwner &&
            ls::spatialScalingRequested(*this->active_profile)) {
        std::cerr << "MAKO Renderer: spatial scaling capability relay: "
                  << "role=" << layerRoleName
                  << "; requested=" << modification.applicationExtent.width
                  << 'x' << modification.applicationExtent.height
                  << "; action=forward-unchanged"
                  << "; ownership=lower-spatial-role\n";
    }

    if (!awaitingLowerCreateRelay && shouldRejectUnmatchedFixedSpatialCreate(
            fixedVirtualSourceRequest, scalingExtents.has_value())) {
        throw ls::vulkan_error(
            VK_ERROR_INITIALIZATION_FAILED,
            "fixed-surface spatial scaling create request does not match the "
            "latest capability contract; inactive_reason=" +
                std::string(spatialScalingInactiveReasonName(inactiveReason))
        );
    }
    if (scalingExtents && !spatialScalingSupported &&
            fixedSurfaceExtent(caps.currentExtent)) {
        // A fixed surface was previously advertised at the virtual source
        // extent. Passing that low extent to the real WSI surface without a
        // scaler would either fail lower creation or expose an incomplete
        // top-left frame. Reject an unexpected format-capability mismatch
        // explicitly instead of silently violating the advertised contract.
        throw ls::vulkan_error(
            VK_ERROR_INITIALIZATION_FAILED,
            !spatialShapeSupported
                ? "fixed-surface spatial scaling requires an opaque, "
                  "single-layer, unprotected, non-shared-present swapchain"
                : (queueFamilySupportsPresentation != VK_TRUE
                    ? "MAKO's graphics/compute queue family cannot present to "
                      "the fixed surface"
                    : (!spatialQueueCommandsSupported
                        ? "MAKO's presentation queue family lacks graphics and "
                          "compute support"
                    : "the selected fixed-surface format cannot be spatially scaled")
                    )
        );
    }

    // vkBasalt hands MAKO its own images; only a build that keeps its views
    // valid with storage usage advertises the capability below it.
    using StorageUsageSupported = VkBool32 (VKAPI_PTR *)(VkDevice);
    const auto storageUsageSupported = reinterpret_cast<StorageUsageSupported>(
        vk.fi().GetDeviceProcAddr(vk.dev(), "makoSwapchainStorageUsageSupportedV1"));
    const bool shaderLayerBlocksStorage =
        environmentFlagEnabled(std::getenv("ENABLE_VKBASALT")) &&
        !(storageUsageSupported && storageUsageSupported(vk.dev()) == VK_TRUE);
    const auto scalingMethod = ls::effectiveScalingMethod(contextProfile);
    const bool directSpatialOutput = directSpatialPresentationRequested(
            modification.spatialScalingActive,
            ls::spatialScalingRequested(contextProfile), scalingMethod,
            !this->fp16RequestedAtStartup() || vk.supportsFP16(),
            shaderLayerBlocksStorage) &&
        SpatialScaler::directPresentationOutputSupported(
            vk, createInfo, caps.supportedUsageFlags,
            scalingMethod == ls::ScalingMethod::Mako &&
                this->fp16RequestedAtStartup());
    if (shaderLayerBlocksStorage && modification.spatialScalingActive &&
            scalingMethod != ls::ScalingMethod::Native) {
        std::cerr << "MAKO Renderer: spatial scaling presentation transport: "
                     "mode=copy-private-output; "
                     "reason=shader-layer-without-storage-safe-views\n";
    }
    modification.privateOrderedTransport = context_ModifySwapchainCreateInfo(
        contextProfile,
        caps.maxImageCount,
        createInfo,
        (!this->presentationEnvironment.gamescopeWsiDisabled &&
            this->gamescopeHdrActive.value_or(false)),
        this->gamescopeDetected,
        this->presentationEnvironment,
        frameGenerationAvailable,
        modification.spatialScalingActive,
        directSpatialOutput
    );

    // Gamescope forwards both a MAILBOX base mode and a MAILBOX-only
    // maintenance1 compatibility list. The private SDR transport changes the
    // base mode to FIFO, so that list must not reach the lower driver: leaving
    // it attached makes the create description inconsistent and has surfaced
    // as a Wine vkCreateSwapchainKHR assertion. Remove only the outer node from
    // our lower-facing chain. Copy a known prefix so neither the immutable mode
    // array nor any caller-owned pNext link is ever rewritten. The Gamescope
    // HDR transport preserves the complete compositor contract.
    const FilteredSwapchainCreatePNextChain presentModes(
        createInfo.pNext,
        VK_STRUCTURE_TYPE_SWAPCHAIN_PRESENT_MODES_CREATE_INFO_EXT,
        modification.privateOrderedTransport
    );
    if (!presentModes.valid()) {
        throw ls::error(
            "unsupported VkSwapchainCreateInfoKHR pNext prefix before "
            "Gamescope present-mode filtering: " +
            std::to_string(presentModes.unsupportedStructureType())
        );
    }
    createInfo.pNext = presentModes.head();

    const bool mailboxPresentation =
        contextProfile.mailbox_presentation_compatibility;
    bool lowerMailboxSupported = false;
    if ((gamescopeScalingSurface || mailboxPresentation) &&
            modification.privateOrderedTransport &&
            vk.fi().GetPhysicalDeviceSurfacePresentModesKHR) {
        // This bounded create-time query leaves FIFO intact if the driver
        // cannot prove support. No capability query belongs in presentation.
        std::array<VkPresentModeKHR, 16> modes{};
        uint32_t count = static_cast<uint32_t>(modes.size());
        const auto result = vk.fi().GetPhysicalDeviceSurfacePresentModesKHR(
            vk.physdev(), createInfo.surface, &count, modes.data()
        );
        lowerMailboxSupported = result == VK_SUCCESS && count <= modes.size() &&
            std::ranges::find(std::span{modes}.first(count),
                VK_PRESENT_MODE_MAILBOX_KHR) != std::span{modes}.first(count).end();
    }
    const auto gamescopePresentContract =
        gamescopeScalingPresentContract(
            createInfo.presentMode,
            gamescopeScalingSurface,
            modification.privateOrderedTransport,
            lowerMailboxSupported,
            this->gamescopeRefreshHz &&
                OrderedPresentTimeline::validRate(*this->gamescopeRefreshHz),
            mailboxPresentation
        );
    if (mailboxPresentation && modification.privateOrderedTransport) {
        std::cerr << "MAKO Renderer: Mailbox Presentation compatibility: "
                     "lower_present_mode="
                  << (gamescopePresentContract.lowerPresentMode ==
                          VK_PRESENT_MODE_MAILBOX_KHR
                      ? "mailbox" : "fifo")
                  << "; mailbox_supported=" << lowerMailboxSupported
                  << "; bridge=" << gamescopeScalingSurface << '\n';
    }
    createInfo.presentMode = gamescopePresentContract.lowerPresentMode;
    modification.gamescopeProtocolPresentMode =
        gamescopePresentContract.compositorPresentMode;
    // Mailbox Presentation needs no refresh clock; zero leaves the bridge's
    // FIFO timeline unarmed.
    if (modification.gamescopeProtocolPresentMode)
        modification.gamescopePresentRefreshHz =
            this->gamescopeRefreshHz.value_or(0);

    finish();
    if (modification.spatialScalingActive && !spatialExtentOwner) {
        // The lower extent owner expanded the real swapchain after Gamescope
        // WSI observed the source-sized request. Reflect that immutable extent
        // only in this upper layer's local create description so its combined
        // scaler/FG context maps the actual presentation-sized images.
        createInfo.imageExtent = modification.presentationExtent;
    } else {
        modification.presentationExtent = createInfo.imageExtent;
    }
    return modification;
}

std::optional<SpatialScalingCapabilitySelection>
Root::modifySurfaceCapabilities(
        VkSurfaceCapabilitiesKHR& capabilities) const {
    const auto snapshot = this->surfaceScalingPolicySnapshot();
    if (!snapshot.policy.enabled || !snapshot.processSupported)
        return std::nullopt;
    const auto extents = virtualizeSurfaceCapabilities(
        snapshot.policy, capabilities
    );
    if (!extents)
        return std::nullopt;
    return SpatialScalingCapabilitySelection{
        .extents = *extents,
        .factor = snapshot.policy.factor,
        .policyRevision = snapshot.revision,
    };
}

namespace {
    present_diagnostics::RuntimeHealthPaths healthPathsForDevice(const vk::Vulkan& vk) {
        present_diagnostics::RuntimeHealthPaths paths;
        if (vk.fi().GetPhysicalDeviceProperties2 && physicalDeviceSupportsExtension(
                vk.fi(), vk.physdev(), VK_EXT_PHYSICAL_DEVICE_DRM_EXTENSION_NAME)) {
            VkPhysicalDeviceDrmPropertiesEXT drm{
                .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DRM_PROPERTIES_EXT,
            };
            VkPhysicalDeviceProperties2 properties{
                .sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2,
                .pNext = &drm,
            };
            vk.fi().GetPhysicalDeviceProperties2(vk.physdev(), &properties);
            if (drm.hasRender && drm.renderMajor >= 0 && drm.renderMinor >= 0 &&
                    drm.renderMajor <= std::numeric_limits<uint32_t>::max() &&
                    drm.renderMinor <= std::numeric_limits<uint32_t>::max()) {
                paths.gpu = present_diagnostics::DrmRenderNode{
                    static_cast<uint32_t>(drm.renderMajor), static_cast<uint32_t>(drm.renderMinor)};
            }
        }
        return paths;
    }
}

std::shared_ptr<present_diagnostics::GpuLoadMonitor> Root::gpuLoadForDevice(const vk::Vulkan& vk) noexcept {
    try {
        const auto accounting = vk.deviceMemoryAccounting();
        for (const auto& device : this->gpuLoadDevices)
            if (device.accounting == accounting)
                return device.monitor;
        if (this->gpuLoadDevices.size() >= 4)
            return {};
        auto monitor = std::make_shared<present_diagnostics::GpuLoadMonitor>(healthPathsForDevice(vk));
        monitor->setEnabled(this->active_profile && this->active_profile->gpu_headroom_percent > 0 &&
            this->active_profile->frame_generation_enabled);
        this->gpuLoadDevices.push_back({accounting, monitor});
        return monitor;
    } catch (...) { return {}; }
}

void Root::startRuntimeHealth(const vk::Vulkan& vk) noexcept {
    if (!present_diagnostics::enabled())
        return;
    try {
        const auto accounting = vk.deviceMemoryAccounting();
        if (this->healthMonitors.contains(accounting.get()))
            return;
        // Bound threads and retained counters even if a game continually
        // creates devices. Swapchain recreation on one device reuses its monitor.
        if (this->healthMonitors.size() >= 4) {
            if (!this->healthMonitorLimitReported) {
                this->healthMonitorLimitReported = true;
                std::cerr << "MAKO Renderer: present diagnostics: operation=runtime-health-unavailable"
                             " reason=device-monitor-limit\n";
            }
            return;
        }
        const auto paths = healthPathsForDevice(vk);
        const auto monitor = present_diagnostics::allocateContextId();
        const auto device = reinterpret_cast<uintptr_t>(vk.dev());
        const long ticks = sysconf(_SC_CLK_TCK);
        this->healthMonitors.emplace(accounting.get(),
            std::make_unique<present_diagnostics::RuntimeHealthMonitor>(paths,
                accounting, this->backend.has_value()
                    ? this->backend->deviceMemoryAccounting() : nullptr,
                [paths, monitor, device, ticks](const auto& sample) {
                    std::cerr << present_diagnostics::formatRuntimeHealth(
                        sample, monitor, layerRoleName, paths, ticks, device);
                }));
    } catch (...) {
        // Diagnostics never fail swapchain creation or alter recovery policy.
        try {
            std::cerr << "MAKO Renderer: present diagnostics: operation=runtime-health-unavailable"
                         " reason=monitor-initialization-failed\n";
        } catch (...) {}
    }
}

void Root::createSwapchainContext(const vk::Vulkan& vk,
        VkSwapchainKHR swapchain, const SwapchainInfo& info,
        const bool swapchainMaintenance1Enabled) {
    if (!this->active_profile.has_value())
        throw ls::error("attempted to create swapchain context while layer is inactive");
    auto profile = profileForLayerContext(*this->active_profile);
    profile.frame_generation_provisioned =
        this->frameGenerationInteropProvisionedAtStartup;
    const auto& global = this->config.get().global();

    std::optional<std::filesystem::path> scalingShaderDll;
    if (info.spatialScalingActive && !info.bridgeDisplayResize) {
        try {
            scalingShaderDll = global.dll.has_value()
                ? std::filesystem::path(*global.dll)
                : std::filesystem::path(ls::findShaderDll());
        } catch (const std::exception& error) {
            // Native Resolution and MAKO do not require the licensed shader,
            // but retaining its path while the Scaling Engine is provisioned
            // is what makes a later private LS1 selection genuinely live.
            if (ls::licensedScalingModelRequested(
                    ls::effectiveScalingMethod(profile))) {
                std::cerr << "MAKO Renderer: unable to locate Lossless.dll for LS1; "
                             "the MAKO fallback will be used: "
                          << error.what() << '\n';
            }
        }
    }

    std::optional<std::string> backendInitializationError;
    const bool frameGenerationRequested =
        profile.frame_generation_provisioned &&
        profile.frame_generation_enabled;
    const bool frameGenerationAvailableOnDevice =
        frameGenerationInteropForLayer(vk.frameGenerationInteropEnabled());
    if (frameGenerationAvailableOnDevice &&
            !this->backend.has_value()) { // emplace backend late, due to loader bug
        try {
            // The backend owns a separate Vulkan instance. Prevent MAKO
            // Renderer, Gamescope WSI, or a selected post-process layer from
            // entering that internal instance while preserving caller values
            // for the rest of the game process. The split chain has two MAKO
            // identities, so disabling only the upper identity would let the
            // lower role intercept the backend device and break construction.
            const ScopedEnvironmentOverride disableMako(
                "DISABLE_MAKO", "1"
            );
            const ScopedEnvironmentOverride disableSpatialMako(
                "DISABLE_MAKO_SPATIAL_SCALING", "1"
            );
            const ScopedEnvironmentOverride disableGamescopeWsi(
                "DISABLE_GAMESCOPE_WSI", "1"
            );
            const ScopedEnvironmentOverride disableMangoHud(
                "MANGOHUD", "0"
            );
            const ScopedEnvironmentOverride disableVkBasalt(
                "ENABLE_VKBASALT", "0"
            );
            const auto applicationDevice = identifyApplicationDevice(vk);
            if (profile.gpu) {
                std::cerr << "MAKO Renderer: backend GPU selection: configured="
                          << *profile.gpu << '\n';
            } else {
                std::cerr << "MAKO Renderer: backend GPU selection: following game device="
                          << applicationDevice.name << " ("
                          << applicationDevice.vendorId << ":"
                          << applicationDevice.deviceId << ")\n";
            }

            const backend::DevicePicker devicePicker = [gpu = profile.gpu, applicationDevice](
                    const std::string& deviceName,
                    std::pair<const std::string&, const std::string&> ids,
                    const std::optional<std::string>& pci
                ) {
                    return matchesBackendDevice(
                        {
                            .name = deviceName,
                            .vendorId = ids.first,
                            .deviceId = ids.second,
                            .pci = pci,
                        },
                        gpu,
                        applicationDevice
                    );
                };
            const auto appliedModel = initializeFrameGenerationBackend(
                profile.frame_generation_model,
                [&](ls::FrameGenerationModel model) {
                    std::string dll;
                    std::optional<std::filesystem::path> modelPackage;
                    if (model == ls::FrameGenerationModel::MakoFg)
                        modelPackage = ls::makoFgPackagePath();
                    else
                        dll = global.dll ? *global.dll : ls::findShaderDll().string();
                    this->backend.emplace(
                        devicePicker, dll, this->fp16AtStartup, modelPackage,
                        identifyApplicationDriver(vk)
                    );
                },
                [](const std::exception& error) {
                    std::cerr << "MAKO Renderer: fg-model operation=fallback requested=lossless-scaling"
                                 " next=mako-fg reason=backend-initialization-failed\n- "
                              << error.what() << '\n';
                }
            );
            this->backendGlobal = global;
            this->backendGlobal->allow_fp16 = this->fp16AtStartup;
            this->backendProfile = profile;
            this->backendProfile->frame_generation_model = appliedModel;
            if (appliedModel != profile.frame_generation_model) {
                this->frameGenerationModelFallbackFrom =
                    profile.frame_generation_model;
                this->active_profile->frame_generation_model = appliedModel;
            }
        } catch (const std::exception& e) {
            backendInitializationError = e.what();
            if (frameGenerationRequested && !info.spatialScalingActive)
                throw ls::error("failed to create backend instance", e);
        }
    }

    backend::Instance* frameGenerationBackend =
        frameGenerationAvailableOnDevice && this->backend.has_value()
        ? &this->backend.mut() : nullptr;
    if (frameGenerationRequested && !vk.frameGenerationInteropEnabled()) {
        std::cerr << "MAKO Renderer: frame generation was enabled after the "
                     "application device was created without external interop; "
                     "a game restart is required; independent spatial scaling "
                     "remains available\n";
    } else if (frameGenerationRequested && !frameGenerationBackend &&
            info.spatialScalingActive) {
        std::cerr << "MAKO Renderer: frame-generation backend initialization "
                     "failed; independent spatial scaling retained:\n"
                  << "- "
                  << backendInitializationError.value_or("unknown failure")
                  << '\n';
    } else if (!frameGenerationAvailableOnDevice &&
            !frameGenerationRequested && info.spatialScalingActive) {
        std::cerr << "MAKO Renderer: standalone spatial scaling: "
                     "frame-generation backend and interop resources were not "
                     "created\n";
    }

    auto contextProfile = this->backendProfile
        ? profileForExistingBackend(profile, *this->backendProfile)
        : profile;
    if (!frameGenerationAvailableOnDevice)
        contextProfile.frame_generation_enabled = false;
    const auto memoryBefore = vk.deviceMemorySnapshot();
    const bool inserted = this->swapchains.emplace(swapchain,
        Swapchain(vk, frameGenerationBackend, std::move(contextProfile), info,
            std::move(scalingShaderDll), this->fp16AtStartup,
            this->presentationEnvironment.gamescopeWsiDisabled
                ? std::optional<bool>{false} : this->gamescopeHdrActive,
            this->gamescopeDetected,
            this->presentationEnvironment.hdrExposureDisabled,
            this->gamescopeRefreshHz,
            this->gamescopePresentationFeedback,
            this->runtimeStateRevision,
            swapchainMaintenance1Enabled)).second;
    const auto memoryAfter = vk.deviceMemorySnapshot();
    this->startRuntimeHealth(vk);
    const auto contextInternal = memoryDelta(
        memoryAfter.internal, memoryBefore.internal);
    const auto contextExported = memoryDelta(
        memoryAfter.exported, memoryBefore.exported);
    const auto contextImported = memoryDelta(
        memoryAfter.imported, memoryBefore.imported);
    const auto insertedContext = this->swapchains.find(swapchain);
    if (insertedContext != this->swapchains.end())
        insertedContext->second.updateGamescopeFocus(this->gamescopeFocus);
    const uint64_t diagnosticsContextId =
        insertedContext != this->swapchains.end()
        ? insertedContext->second.diagnosticsId()
        : 0;
    const VkExtent2D frameGenerationResourceExtent =
        insertedContext != this->swapchains.end()
        ? insertedContext->second.frameGenerationResourceExtent()
        : info.extent;
    const auto framePipelinePlacement =
        insertedContext != this->swapchains.end()
        ? insertedContext->second.framePipelinePlacement()
        : SpatialFramePipelinePlacement::PreFrameGeneration;

    std::clog << "MAKO Renderer: renderer-memory operation=swapchain-context-create"
        << " context=" << diagnosticsContextId
        << " role=" << layerRoleName
        << " width=" << info.extent.width
        << " height=" << info.extent.height
        << " frame_generation_width="
        << frameGenerationResourceExtent.width
        << " frame_generation_height="
        << frameGenerationResourceExtent.height
        << " context_internal_bytes=" << contextInternal.bytes
        << " context_internal_allocations=" << contextInternal.allocations
        << " context_exported_bytes=" << contextExported.bytes
        << " context_exported_allocations=" << contextExported.allocations
        << " context_imported_mapped_bytes=" << contextImported.bytes
        << " context_imported_allocations=" << contextImported.allocations
        << " live_internal_bytes=" << memoryAfter.internal.bytes
        << " live_internal_allocations=" << memoryAfter.internal.allocations
        << " live_exported_bytes=" << memoryAfter.exported.bytes
        << " live_exported_allocations=" << memoryAfter.exported.allocations
        << " peak_internal_bytes=" << memoryAfter.peakInternal.bytes
        << " peak_internal_allocations="
        << memoryAfter.peakInternal.allocations
        << " peak_exported_bytes=" << memoryAfter.peakExported.bytes
        << " peak_exported_allocations="
        << memoryAfter.peakExported.allocations
        << '\n';

    if (present_diagnostics::enabled()) {
        std::cerr << "MAKO Renderer: present diagnostics: operation=swapchain-context-create"
                  << " context=" << diagnosticsContextId
                  << " pid=" << ::getpid()
                  << " role=" << layerRoleName
                  << " swapchain=" << swapchain
                  << " width=" << info.extent.width
                  << " height=" << info.extent.height
                  << " application_width=" << info.applicationExtent.width
                  << " application_height=" << info.applicationExtent.height
                  << " frame_generation_width="
                  << frameGenerationResourceExtent.width
                  << " frame_generation_height="
                  << frameGenerationResourceExtent.height
                  << " spatial_pipeline="
                  << spatialFramePipelinePlacementName(
                        framePipelinePlacement
                     )
                  << " requested_min_images="
                  << info.requestedMinImageCount
                  << " provisioned_min_images="
                  << info.provisionedMinImageCount
                  << " swapchain_image_count_compatibility="
                  << info.swapchainImageCountCompatibility
                  << " images=" << info.images.size()
                  << " format=" << static_cast<int>(info.format)
                  << " color_space=" << static_cast<int>(info.colorSpace)
                  << " incoming_present_mode="
                  << static_cast<int>(info.incomingPresentMode)
                  << " present_mode=" << static_cast<int>(info.presentMode)
                  << " ordered_transport="
                  << (info.privateOrderedTransport ? 1 : 0)
                  << " spatial_scaling_activation_supported="
                  << (info.spatialScalingActivationSupported ? 1 : 0)
                  << " spatial_scaling_admission_retry_eligible="
                  << (info.spatialScalingAdmissionRetryEligible ? 1 : 0)
                  << " replacement=" << (info.replacement ? 1 : 0)
                  << " active_contexts=" << this->swapchains.size()
                  << " inserted=" << inserted
                  << " present_retirement="
                  << (insertedContext != this->swapchains.end() &&
                        insertedContext->second.presentRetirementEnabled()
                        ? "maintenance1-fence" : "natural-only")
                  << " live_profile_recreation=guarded-maintenance1-one-shot"
                  << '\n';
    }
}

void Root::removeSwapchainContext(VkSwapchainKHR swapchain) {
    static_cast<void>(this->takeSwapchainContext(swapchain));
}

std::optional<Swapchain> Root::takeSwapchainContext(
        const VkSwapchainKHR swapchain) {
    auto context = this->swapchains.extract(swapchain);
    const uint64_t diagnosticsContextId = context.empty()
        ? 0 : context.mapped().diagnosticsId();
    const bool removed = !context.empty();
    if (present_diagnostics::enabled()) {
        std::cerr << "MAKO Renderer: present diagnostics: operation=swapchain-context-destroy"
                  << " context=" << diagnosticsContextId
                  << " role=" << layerRoleName
                  << " swapchain=" << swapchain
                  << " active_contexts=" << this->swapchains.size()
                  << " removed=" << removed << '\n';
    }
    if (context.empty())
        return std::nullopt;
    return std::optional<Swapchain>{std::move(context.mapped())};
}
