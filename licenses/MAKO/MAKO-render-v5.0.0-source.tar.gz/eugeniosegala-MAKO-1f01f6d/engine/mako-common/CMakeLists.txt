set(COMMON_SOURCES
    "src/configuration/config.cpp"
    "src/configuration/detection.cpp"
    "src/configuration/launch.cpp"
    "src/configuration/power_source.cpp"
    "src/configuration/vkbasalt.cpp"
    "src/helpers/errors.cpp"
    "src/helpers/paths.cpp"
    "src/quality/image_quality.cpp"
    "src/vulkan/buffer.cpp"
    "src/vulkan/command_buffer.cpp"
    "src/vulkan/descriptor_pool.cpp"
    "src/vulkan/descriptor_set.cpp"
    "src/vulkan/device_memory_accounting.cpp"
    "src/vulkan/fence.cpp"
    "src/vulkan/image.cpp"
    "src/vulkan/image_memory_pool.cpp"
    "src/vulkan/sampler.cpp"
    "src/vulkan/semaphore.cpp"
    "src/vulkan/shader.cpp"
    "src/vulkan/timeline_semaphore.cpp"
    "src/vulkan/vulkan.cpp")

add_library(mako-common STATIC ${COMMON_SOURCES})

find_package(Threads REQUIRED)
target_link_libraries(mako-common PUBLIC Threads::Threads)

target_include_directories(mako-common
    PUBLIC include)

target_include_directories(mako-common SYSTEM
    PRIVATE thirdparty/include)

if(BUILD_TESTING)
    add_executable(mako-shader-pipeline-tests "tests/shader_pipeline_tests.cpp")
    target_link_libraries(mako-shader-pipeline-tests PRIVATE mako-common)
    add_test(NAME shader-pipeline-ownership COMMAND mako-shader-pipeline-tests)
    set_tests_properties(shader-pipeline-ownership PROPERTIES LABELS "portable-policy")

    if(UNIX)
        add_test(NAME launcher-exclusions-freshness
            COMMAND "${MAKO_PYTHON3_EXECUTABLE}"
                "${CMAKE_CURRENT_SOURCE_DIR}/../../scripts/generate-launcher-exclusions.py"
                --check)
        set_tests_properties(launcher-exclusions-freshness PROPERTIES
            LABELS "portable-policy")
    endif()

    add_executable(mako-external-fd-tests "tests/external_fd_tests.cpp")
    target_link_libraries(mako-external-fd-tests PRIVATE mako-common)
    add_test(NAME external-fd-ownership COMMAND mako-external-fd-tests)

    add_executable(mako-descriptor-pool-tests "tests/descriptor_pool_tests.cpp")
    target_link_libraries(mako-descriptor-pool-tests PRIVATE mako-common)
    add_test(NAME descriptor-pool-capacity COMMAND mako-descriptor-pool-tests)
    set_tests_properties(external-fd-ownership descriptor-pool-capacity PROPERTIES
        LABELS "portable-policy")

    add_executable(mako-dll-paths-tests "tests/paths_tests.cpp")
    target_link_libraries(mako-dll-paths-tests PRIVATE mako-common)
    add_test(NAME lossless-dll-discovery COMMAND mako-dll-paths-tests)

    add_executable(mako-config-tests
        "tests/config_tests.cpp")
    target_link_libraries(mako-config-tests
        PRIVATE mako-common)
    target_include_directories(mako-config-tests PRIVATE src)
    add_test(NAME watched-configuration
        COMMAND mako-config-tests)

    add_executable(mako-power-source-monitor-tests
        "tests/power_source_monitor_tests.cpp")
    target_link_libraries(mako-power-source-monitor-tests PRIVATE mako-common)
    target_include_directories(mako-power-source-monitor-tests PRIVATE src)
    add_test(NAME power-source-monitor COMMAND mako-power-source-monitor-tests)
    set_tests_properties(power-source-monitor PROPERTIES
        LABELS "portable-policy" TIMEOUT 15)

    add_executable(mako-launch-config-tests
        "tests/launch_config_tests.cpp")
    target_link_libraries(mako-launch-config-tests
        PRIVATE mako-common)
    add_test(NAME standalone-launch-configuration
        COMMAND mako-launch-config-tests)

    add_executable(mako-device-feature-tests
        "tests/device_feature_tests.cpp")
    target_link_libraries(mako-device-feature-tests
        PRIVATE mako-common)
    add_test(NAME optional-device-features
        COMMAND mako-device-feature-tests)
    set_tests_properties(optional-device-features PROPERTIES LABELS "portable-policy")

    add_executable(mako-device-memory-accounting-tests
        "tests/device_memory_accounting_tests.cpp")
    target_link_libraries(mako-device-memory-accounting-tests
        PRIVATE mako-common)
    add_test(NAME device-memory-accounting
        COMMAND mako-device-memory-accounting-tests)

    add_executable(mako-image-memory-pool-tests
        "tests/image_memory_pool_tests.cpp")
    target_link_libraries(mako-image-memory-pool-tests
        PRIVATE mako-common)
    add_test(NAME image-memory-pool
        COMMAND mako-image-memory-pool-tests)

    add_executable(mako-command-buffer-submit-storage-tests
        "tests/command_buffer_submit_storage_tests.cpp")
    target_include_directories(mako-command-buffer-submit-storage-tests
        PRIVATE src)
    target_link_libraries(mako-command-buffer-submit-storage-tests PRIVATE mako-common)
    add_test(NAME command-buffer-submit-storage
        COMMAND mako-command-buffer-submit-storage-tests)
    set_tests_properties(command-buffer-submit-storage PROPERTIES LABELS "portable-policy")

    add_executable(mako-image-quality-tests
        "tests/image_quality_tests.cpp")
    target_link_libraries(mako-image-quality-tests
        PRIVATE mako-common)
    add_test(NAME procedural-image-quality-scene
        COMMAND mako-image-quality-tests)
endif()

if(MAKO_INSTALL_DEVELOP)
    install(TARGETS mako-common
        ARCHIVE DESTINATION "${CMAKE_INSTALL_LIBDIR}")
    install(DIRECTORY "include/mako-common/"
        DESTINATION "${CMAKE_INSTALL_INCLUDEDIR}/mako-common"
        FILES_MATCHING PATTERN "*.hpp")
endif()
