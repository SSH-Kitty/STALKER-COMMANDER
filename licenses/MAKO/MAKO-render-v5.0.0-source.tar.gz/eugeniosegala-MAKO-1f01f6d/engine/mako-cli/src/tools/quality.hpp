/* SPDX-License-Identifier: GPL-3.0-or-later */

#pragma once

#include <cstdint>
#include <filesystem>
#include <optional>
#include <string>

namespace mako::cli::quality {

    /// options for the "quality-regression" command
    struct Options {
        bool hdr10{false};
        bool hdr_reduced_precision{false};
        float hdr_white_nits{203.0F};
        /// HDR exchange encoding: packed PQ (A2B10G10R10), half-float PQ or linear scRGB.
        std::string hdr_encoding{"packed"};
        std::optional<std::string> dll;
        bool allow_fp16{true};
        std::optional<std::string> gpu;
        std::optional<std::filesystem::path> output;
        std::optional<std::filesystem::path> input_pair;
        std::string scene{"motion-boundary"};
        float interpolation{0.5F};
        std::optional<std::string> sequence_plan;
        std::optional<uint32_t> width;
        std::optional<uint32_t> height;
        float flow_scale{1.0F};
        bool performance_mode{false};
    };

    /// run the deterministic GPU image-quality regression
    int run(const Options& opts);

    /// Options for the real MAKO/LS1 spatial reconstruction regression.
    struct SpatialOptions {
        std::optional<std::string> dll;
        bool allow_fp16{false};
        std::optional<std::string> gpu;
        std::optional<std::filesystem::path> output;
        std::string scene{"motion-boundary"};
        std::string method{"mako"};
        float scaling_factor{1.5F};
        float sharpness{0.5F};
        float scene_time{0.5F};
        std::optional<uint32_t> width;
        std::optional<uint32_t> height;
    };

    /// Run one procedural scene through the production spatial scaler.
    int runSpatial(const SpatialOptions& opts);

    /// Options for timestamp-query profiling of the production spatial graph.
    struct SpatialProfileOptions {
        std::optional<std::string> dll;
        bool allow_fp16{false};
        std::optional<std::string> gpu;
        std::string method{"mako"};
        uint32_t width{1280};
        uint32_t height{800};
        float scaling_factor{1.5F};
        float sharpness{0.5F};
        uint32_t warmup_iterations{12};
        /// Repeat warm-up batches until this much time has passed, so
        /// automatic GPU clocks settle however cheap one graph is.
        uint32_t warmup_milliseconds{0};
        uint32_t samples{50};
        bool frame_generation_handoff{false};
        /// rgba8, bgra8, a2b10g10r10, a2r10g10b10, rgba16f or scrgb
        std::string presentation_format{"rgba8"};
        /// Reconstruct straight into the application image (not Native).
        bool direct_output{false};
        /// Require byte-identical direct and copy-back output (not Native).
        bool compare_direct_output{false};
    };

    /// Measure the complete production spatial command graph with Vulkan GPU
    /// timestamps. Instrumentation exists only in this CLI path.
    int runSpatialProfile(const SpatialProfileOptions& opts);

    /// Options for proving that synchronization validation is active.
    struct SynchronizationCanaryOptions {
        std::optional<std::string> gpu;
    };

    /// Record one intentional transfer hazard for validation-tooling checks.
    int runSynchronizationCanary(const SynchronizationCanaryOptions& opts);

    /// Options for the production spatial-scaling-to-LSFG handoff.
    struct CombinedOptions {
        std::optional<std::string> dll;
        bool allow_fp16{true};
        std::optional<std::string> gpu;
        std::optional<std::filesystem::path> output;
        std::string scene{"motion-boundary"};
        std::string method{"mako"};
        float scaling_factor{1.5F};
        float sharpness{0.5F};
        float interpolation{0.5F};
        float flow_scale{1.0F};
        bool performance_mode{false};
        std::optional<uint32_t> width;
        std::optional<uint32_t> height;
    };

    /// Scale both low-resolution endpoints and feed the reconstructed frames
    /// into the real licensed frame-generation backend.
    int runCombined(const CombinedOptions& opts);
}
