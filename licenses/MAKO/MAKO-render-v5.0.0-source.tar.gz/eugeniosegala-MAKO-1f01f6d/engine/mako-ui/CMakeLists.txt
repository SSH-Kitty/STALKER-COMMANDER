find_package(Qt6 6.2 REQUIRED COMPONENTS Quick)

set(UI_SOURCES
    "src/backend.cpp"
    "src/model_inspection.cpp"
    "src/main.cpp"
    "src/process_detection.cpp"
    "src/remote_play.cpp"
    "src/utils.cpp")

set(UI_RESOURCES
    "rsc/dialogs/CenteredDialog.qml"
    "rsc/dialogs/LargeDialog.qml"
    "rsc/dialogs/RunningGamesDialog.qml"
    "rsc/dialogs/ShaderParametersWindow.qml"
    "rsc/dialogs/ShaderParameterControl.qml"
    "rsc/dialogs/ShaderControlHelpers.js"
    "rsc/panes/Group.qml"
    "rsc/panes/GroupEntry.qml"
    "rsc/panes/Pane.qml"
    "rsc/widgets/FileEdit.qml"
    "rsc/widgets/FlowSlider.qml"
    "rsc/widgets/List.qml"
    "rsc/widgets/ModelComboBox.qml"
    "rsc/i18n/translations.json"
    "rsc/io.github.eugeniosegala.mako.png"
    "rsc/UI.qml")

add_library(mako-ui-localization STATIC
    "src/localization.cpp")
set_target_properties(mako-ui-localization PROPERTIES AUTOMOC ON)
target_include_directories(mako-ui-localization PUBLIC "src")
target_link_libraries(mako-ui-localization PUBLIC Qt6::Core)

qt_add_executable(mako-ui ${UI_SOURCES})

qt_add_resources(mako-ui RESOURCES
    PREFIX "/"
    FILES ${UI_RESOURCES})

set_target_properties(mako-ui PROPERTIES
    AUTOMOC ON
    AUTOUIC ON)

target_compile_options(mako-ui PRIVATE # QT-codegen warnings
    -Wno-unknown-warning-option
    -Wno-ctad-maybe-unsupported
    -Wno-unsafe-buffer-usage-in-libc-call
    -Wno-global-constructors
    -Wno-unsafe-buffer-usage)

target_link_libraries(mako-ui
    PRIVATE mako-common
    PRIVATE mako-backend
    PRIVATE mako-ui-localization
    PRIVATE Qt6::Quick)

set(MAKO_VKBASALT_SHADER_SOURCE_DIR
    "${CMAKE_CURRENT_SOURCE_DIR}/../../plugin/py_modules/mako_plugin/vkbasalt_shaders")
target_compile_definitions(mako-ui PRIVATE
    MAKO_UI_VKBASALT_SHADER_SOURCE_DIR="${MAKO_VKBASALT_SHADER_SOURCE_DIR}")

if(BUILD_TESTING)
    add_executable(mako-ui-process-detection-tests
        "tests/process_detection_tests.cpp"
        "src/backend.cpp"
        "src/model_inspection.cpp"
        "src/backend.hpp"
        "src/process_detection.cpp"
        "src/remote_play.cpp")
    set_target_properties(mako-ui-process-detection-tests PROPERTIES AUTOMOC ON)
    target_include_directories(mako-ui-process-detection-tests PRIVATE "src")
    target_link_libraries(mako-ui-process-detection-tests PRIVATE mako-common Qt6::Core Qt6::Gui)
    add_test(NAME ui-process-detection COMMAND mako-ui-process-detection-tests)

    add_executable(mako-ui-backend-contract-tests
        "tests/backend_contract_tests.cpp"
        "src/backend.cpp"
        "src/model_inspection.cpp"
        "src/process_detection.cpp"
        "src/remote_play.cpp"
        "src/backend.hpp")
    set_target_properties(mako-ui-backend-contract-tests PROPERTIES AUTOMOC ON)
    target_include_directories(mako-ui-backend-contract-tests PRIVATE "src")
    target_link_libraries(mako-ui-backend-contract-tests
        PRIVATE mako-common
        PRIVATE mako-backend
        PRIVATE Qt6::Core
        PRIVATE Qt6::Gui)
    target_compile_definitions(mako-ui-backend-contract-tests PRIVATE
        MAKO_UI_QML_FILE="${CMAKE_CURRENT_SOURCE_DIR}/rsc/UI.qml"
        MAKO_UI_LAUNCHER="${CMAKE_CURRENT_SOURCE_DIR}/../scripts/mako-launch"
        MAKO_UI_REMOTE_PLAY_HELPER="${CMAKE_CURRENT_SOURCE_DIR}/../scripts/mako-remote-play"
        MAKO_UI_GROUP_ENTRY_QML_FILE="${CMAKE_CURRENT_SOURCE_DIR}/rsc/panes/GroupEntry.qml"
        MAKO_UI_VKBASALT_SHADER_SOURCE_DIR="${MAKO_VKBASALT_SHADER_SOURCE_DIR}")
    add_test(NAME ui-backend-contract COMMAND mako-ui-backend-contract-tests)

    add_executable(mako-ui-localization-tests
        "tests/localization_tests.cpp")
    target_link_libraries(mako-ui-localization-tests
        PRIVATE mako-ui-localization
        PRIVATE Qt6::Core)
    target_compile_definitions(mako-ui-localization-tests PRIVATE
        MAKO_UI_TRANSLATIONS_FILE="${CMAKE_CURRENT_SOURCE_DIR}/rsc/i18n/translations.json")
    add_test(NAME ui-localization-unit COMMAND mako-ui-localization-tests)

    add_executable(mako-ui-shader-window-tests "tests/shader_parameters_window_tests.cpp")
    set_target_properties(mako-ui-shader-window-tests PROPERTIES AUTOMOC ON)
    target_link_libraries(mako-ui-shader-window-tests PRIVATE Qt6::Quick)
    target_compile_definitions(mako-ui-shader-window-tests PRIVATE
        MAKO_UI_DIALOGS_DIRECTORY="${CMAKE_CURRENT_SOURCE_DIR}/rsc/dialogs")
    add_test(NAME ui-shader-window COMMAND mako-ui-shader-window-tests)
    set_tests_properties(ui-shader-window PROPERTIES ENVIRONMENT "QT_QPA_PLATFORM=offscreen;QT_QUICK_BACKEND=software")

    add_executable(mako-ui-profile-dialog-tests "tests/profile_dialog_tests.cpp")
    target_link_libraries(mako-ui-profile-dialog-tests PRIVATE Qt6::Quick)
    target_compile_definitions(mako-ui-profile-dialog-tests PRIVATE
        MAKO_UI_DIALOGS_DIRECTORY="${CMAKE_CURRENT_SOURCE_DIR}/rsc/dialogs"
        MAKO_UI_WIDGETS_DIRECTORY="${CMAKE_CURRENT_SOURCE_DIR}/rsc/widgets")
    add_test(NAME ui-profile-dialog COMMAND mako-ui-profile-dialog-tests)
    set_tests_properties(ui-profile-dialog PROPERTIES
        ENVIRONMENT "QT_QPA_PLATFORM=offscreen;QT_QUICK_BACKEND=software")
endif()

install(TARGETS mako-ui
    RUNTIME DESTINATION "${CMAKE_INSTALL_BINDIR}")
install(DIRECTORY "${MAKO_VKBASALT_SHADER_SOURCE_DIR}/"
    DESTINATION "${CMAKE_INSTALL_DATAROOTDIR}/mako-render/vkbasalt-shaders")
if(MAKO_INSTALL_XDG_FILES)
    foreach(MAKO_ICON_SIZE IN ITEMS 16 24 32 48 64 128)
        install(FILES
            "rsc/icons/${MAKO_ICON_SIZE}x${MAKO_ICON_SIZE}/io.github.eugeniosegala.mako.png"
            DESTINATION
            "${CMAKE_INSTALL_DATAROOTDIR}/icons/hicolor/${MAKO_ICON_SIZE}x${MAKO_ICON_SIZE}/apps")
    endforeach()
    install(FILES "rsc/io.github.eugeniosegala.mako.png"
        DESTINATION "${CMAKE_INSTALL_DATAROOTDIR}/icons/hicolor/256x256/apps")
    install(FILES
            "rsc/io.github.eugeniosegala.mako.desktop"
            "rsc/io.github.eugeniosegala.mako.uninstaller.desktop"
        DESTINATION "${CMAKE_INSTALL_DATAROOTDIR}/applications")
endif()
